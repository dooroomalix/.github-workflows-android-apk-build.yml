SceneSlate v0.2.6 - enlarged preview and readable board PNG update
