package com.sceneslate.studio.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.File

@Composable
fun SceneSlateMainScreen(viewModel: SceneSlateViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf("이미지") }
    var selectedImageIndex by remember { mutableStateOf(0) }

    LaunchedEffect(uiState.imageFilePaths) {
        selectedImageIndex = 0
        if (uiState.imageFilePaths.isNotEmpty()) selectedTab = "이미지"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 6.dp)
    ) {
        Text(text = "SceneSlate v0.2.6", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = "샘플: ${uiState.currentSampleName} · 상태: ${uiState.status}", style = MaterialTheme.typography.bodyMedium)

        val passText = when {
            uiState.qualityReport.contains("Final Result: PASS") -> "검수 결과: PASS"
            uiState.qualityReport.contains("Final Result: FAIL") -> "검수 결과: FAIL"
            else -> "검수 결과: -"
        }
        Text(text = passText, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)

        if (uiState.projectPath.isNotBlank()) {
            Text(text = uiState.projectPath, style = MaterialTheme.typography.labelSmall, maxLines = 2)
        }

        if (uiState.errorMessage.isNotBlank()) {
            Text(text = "오류: ${uiState.errorMessage}", color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = { viewModel.generateOhmsLawSample(context) }, modifier = Modifier.widthIn(min = 132.dp)) {
                Text("옴 샘플")
            }
            Button(onClick = { viewModel.generateLongQuestionSample(context) }, modifier = Modifier.widthIn(min = 152.dp)) {
                Text("긴 문제 샘플")
            }
            if (uiState.projectPath.isNotBlank()) {
                OutlinedButton(
                    onClick = { copyToClipboard(context, "SceneSlate Project Path", uiState.projectPath) },
                    modifier = Modifier.widthIn(min = 120.dp)
                ) {
                    Text("경로 복사")
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SmallTabButton("검수", selectedTab) { selectedTab = "검수" }
            SmallTabButton("TTS", selectedTab) { selectedTab = "TTS" }
            SmallTabButton("자막", selectedTab) { selectedTab = "자막" }
            SmallTabButton("칠판", selectedTab) { selectedTab = "칠판" }
            SmallTabButton("이미지", selectedTab) { selectedTab = "이미지" }
        }

        Spacer(modifier = Modifier.height(6.dp))

        val displayText = when (selectedTab) {
            "검수" -> uiState.qualityReport
            "TTS" -> uiState.batchInputText
            "자막" -> uiState.subtitlePreview
            "칠판" -> uiState.boardPreviewText
            "이미지" -> uiState.imageListText
            else -> ""
        }

        if (selectedTab == "이미지") {
            ImagePreviewPanel(
                imageFilePaths = uiState.imageFilePaths,
                imageListText = uiState.imageListText,
                selectedImageIndex = selectedImageIndex,
                onSelectImage = { selectedImageIndex = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )
        } else {
            Surface(modifier = Modifier.fillMaxWidth().weight(1f), tonalElevation = 2.dp) {
                Text(
                    text = displayText.ifBlank { "아직 생성된 내용이 없습니다." },
                    modifier = Modifier.padding(12.dp).verticalScroll(rememberScrollState()),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Button(
            onClick = { copyToClipboard(context, "SceneSlate $selectedTab", displayText) },
            enabled = displayText.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("현재 내용 복사") }
    }
}

@Composable
private fun SmallTabButton(title: String, selectedTab: String, onClick: () -> Unit) {
    val selected = title == selectedTab
    val modifier = Modifier.widthIn(min = 92.dp)
    if (selected) {
        Button(onClick = onClick, modifier = modifier) { Text(title) }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier) { Text(title) }
    }
}

@Composable
private fun SceneButton(title: String, selected: Boolean, onClick: () -> Unit) {
    val modifier = Modifier.widthIn(min = 82.dp)
    if (selected) {
        Button(onClick = onClick, modifier = modifier) { Text(title) }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier) { Text(title) }
    }
}

@Composable
private fun ImagePreviewPanel(
    imageFilePaths: List<String>,
    imageListText: String,
    selectedImageIndex: Int,
    onSelectImage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(modifier = modifier, tonalElevation = 2.dp) {
        Column(modifier = Modifier.padding(8.dp)) {
            var previewMode by remember { mutableStateOf("전체") }

            if (imageFilePaths.isEmpty()) {
                Text(text = imageListText.ifBlank { "아직 생성된 이미지가 없습니다." })
                return@Column
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                imageFilePaths.forEachIndexed { index, path ->
                    val label = File(path).name.substringBefore("_")
                    SceneButton(label, index == selectedImageIndex) { onSelectImage(index) }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (previewMode == "전체") {
                    Button(onClick = { previewMode = "전체" }) { Text("전체 보기") }
                } else {
                    OutlinedButton(onClick = { previewMode = "전체" }) { Text("전체 보기") }
                }
                if (previewMode == "확대") {
                    Button(onClick = { previewMode = "확대" }) { Text("확대 보기") }
                } else {
                    OutlinedButton(onClick = { previewMode = "확대" }) { Text("확대 보기") }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            val safeIndex = selectedImageIndex.coerceIn(0, imageFilePaths.lastIndex)
            val imagePath = imageFilePaths[safeIndex]
            Text(text = File(imagePath).name, style = MaterialTheme.typography.labelMedium)
            Spacer(modifier = Modifier.height(6.dp))

            val bitmap = remember(imagePath) { BitmapFactory.decodeFile(imagePath) }

            if (bitmap != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    val imageModifier = if (previewMode == "전체") {
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 16f)
                    } else {
                        Modifier
                            .fillMaxWidth()
                            .height(960.dp)
                    }

                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = File(imagePath).name,
                        modifier = imageModifier,
                        contentScale = if (previewMode == "전체") ContentScale.Fit else ContentScale.FillWidth
                    )
                }
            } else {
                Text(text = "이미지를 불러올 수 없습니다: $imagePath")
            }
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
