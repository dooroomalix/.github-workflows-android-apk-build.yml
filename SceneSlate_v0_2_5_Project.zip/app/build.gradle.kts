plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.sceneslate.studio"
    compileSdk = 35

    signingConfigs {
        create("sslateTest") {
            storeFile = file("keystore/sslate-test.jks")
            storePassword = "SceneSlateTest123!"
            keyAlias = "sslate_test"
            keyPassword = "SceneSlateTest123!"
        }
    }

    defaultConfig {
        applicationId = "com.sceneslate.studio"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "0.2.5"
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("sslateTest")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("sslateTest")
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")

    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
