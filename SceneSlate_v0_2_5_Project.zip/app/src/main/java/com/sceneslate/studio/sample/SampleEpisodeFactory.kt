package com.sceneslate.studio.sample

import com.sceneslate.studio.model.*

object SampleEpisodeFactory {
    fun createOhmsLawEpisode(): EpisodeInput {
        return EpisodeInput(
            project = ProjectInfo(
                appName = "SceneSlate",
                projectName = "SceneSlate Studio",
                codename = "SSlate",
                version = "0.2.5"
            ),
            episode = EpisodeInfo(
                episodeId = "SSlate_EP001",
                title = "옴의 법칙",
                subject = "회로이론",
                level = "초급",
                targetDurationSec = 45,
                language = "ko"
            ),
            character = CharacterInfo(
                characterId = "lilith",
                displayName = "리리스",
                role = "sample_host",
                voicePreset = "Lilith_CalmTeacher"
            ),
            questionSet = QuestionSet(
                question = "저항이 일정할 때, 전압이 2배가 되면 전류는 어떻게 되는가?",
                choices = listOf("절반이 된다", "2배가 된다", "4배가 된다", "변하지 않는다"),
                answerIndex = 2,
                answerText = "2배가 된다"
            ),
            learning = LearningInfo(
                coreFormula = "I = V / R",
                hint = "저항이 일정하다는 조건이야.",
                reason = "저항 R이 일정하면 전류 I는 전압 V에 비례한다. 따라서 전압이 2배가 되면 전류도 2배가 된다.",
                solutionSteps = listOf("I = V / R", "R은 일정", "V 2배 → I 2배"),
                summary = listOf("조건 먼저 확인", "R 일정이면 I는 V에 비례", "공식은 뜻으로 기억")
            ),
            style = StyleInfo(
                sceneCount = 6,
                format = "vertical_9_16",
                subtitleRule = SceneSlateRules.SUBTITLE_SAME_AS_TTS,
                boardRole = SceneSlateRules.BOARD_LEARNING_INFORMATION,
                tone = "calm_teacher_dark_academy",
                cta = "다음 문제도 풀어보자."
            )
        )
    }

    fun createLongQuestionEpisode(): EpisodeInput {
        return EpisodeInput(
            project = ProjectInfo(
                appName = "SceneSlate",
                projectName = "SceneSlate Studio",
                codename = "SSlate",
                version = "0.2.5"
            ),
            episode = EpisodeInfo(
                episodeId = "SSlate_EP002",
                title = "긴 문제 자동 맞춤",
                subject = "전기자기학",
                level = "중급",
                targetDurationSec = 45,
                language = "ko"
            ),
            character = CharacterInfo(
                characterId = "lilith",
                displayName = "리리스",
                role = "sample_host",
                voicePreset = "Lilith_CalmTeacher"
            ),
            questionSet = QuestionSet(
                question = "정전용량이 20μF인 공기 중 평행판 커패시터에 0.1C의 전하량을 충전하였다. 두 평행판 사이에 비유전율이 10인 유전체를 채웠을 때 유전체 표면에 나타나는 분극 전하량은?",
                choices = listOf(
                    "0.009C",
                    "0.01C",
                    "0.09C",
                    "0.1C"
                ),
                answerIndex = 3,
                answerText = "0.09C"
            ),
            learning = LearningInfo(
                coreFormula = "Q' = Q(1 - 1/εr)",
                hint = "비유전율이 들어가면 분극 전하량 공식을 확인해야 해.",
                reason = "분극 전하량은 Q' = Q(1 - 1/εr)로 계산한다. Q가 0.1C이고 εr이 10이므로 Q'는 0.09C가 된다.",
                solutionSteps = listOf(
                    "Q' = Q(1 - 1/εr)",
                    "Q = 0.1C, εr = 10",
                    "Q' = 0.1 × 0.9 = 0.09C"
                ),
                summary = listOf(
                    "유전체 문제는 공식 확인",
                    "비유전율은 εr로 본다",
                    "분극 전하량은 0.09C"
                )
            ),
            style = StyleInfo(
                sceneCount = 6,
                format = "vertical_9_16",
                subtitleRule = SceneSlateRules.SUBTITLE_SAME_AS_TTS,
                boardRole = SceneSlateRules.BOARD_LEARNING_INFORMATION,
                tone = "calm_teacher_dark_academy",
                cta = "다음 문제도 풀어보자."
            )
        )
    }
}
