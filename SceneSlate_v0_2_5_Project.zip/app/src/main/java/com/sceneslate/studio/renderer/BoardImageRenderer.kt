package com.sceneslate.studio.renderer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.sceneslate.studio.model.SceneSpec
import com.sceneslate.studio.model.SceneSpecDocument
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

object BoardImageRenderer {
    private const val WIDTH = 1080
    private const val HEIGHT = 1920

    // v0.2.5: keep the board large, but use AutoFit text sizing for long questions.
    private val boardRect = RectF(28f, 48f, 1052f, 1842f)
    private const val PAD = 62f

    private val chalk = Color.rgb(246, 250, 238)
    private val warm = Color.rgb(255, 236, 160)
    private val boardGreen = Color.rgb(14, 61, 50)
    private val panelGreen = Color.rgb(31, 88, 65)
    private val lineGreen = Color.rgb(143, 181, 147)
    private val alertRed = Color.rgb(180, 91, 104)

    fun renderAll(document: SceneSpecDocument, projectDir: File): List<File> {
        val imageDir = File(projectDir, "images")
        if (!imageDir.exists()) imageDir.mkdirs()

        return document.scenes.map { scene ->
            val file = File(imageDir, createImageFileName(scene.sceneId))
            renderScene(scene, file)
            file
        }
    }

    private fun renderScene(scene: SceneSpec, outputFile: File) {
        val bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        drawBackground(canvas)
        drawBoard(canvas)

        when (scene.sceneId) {
            "SC01" -> renderProblem(canvas, scene)
            "SC02" -> renderChoices(canvas, scene)
            "SC03" -> renderHint(canvas, scene)
            "SC04" -> renderSolution(canvas, scene)
            "SC05" -> renderAnswer(canvas, scene)
            "SC06" -> renderSummary(canvas, scene)
            else -> renderDefault(canvas, scene)
        }

        drawFooter(canvas, scene)

        FileOutputStream(outputFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        bitmap.recycle()
    }

    private fun drawBackground(canvas: Canvas) {
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(239, 235, 247)
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, WIDTH.toFloat(), HEIGHT.toFloat(), bg)
    }

    private fun drawBoard(canvas: Canvas) {
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(74, 0, 0, 0)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(
            RectF(boardRect.left + 12f, boardRect.top + 14f, boardRect.right + 12f, boardRect.bottom + 14f),
            42f,
            42f,
            shadow
        )

        val board = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = boardGreen; style = Paint.Style.FILL }
        val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(220, 235, 220); style = Paint.Style.STROKE; strokeWidth = 10f }
        val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(76, 125, 99); style = Paint.Style.STROKE; strokeWidth = 4f }
        canvas.drawRoundRect(boardRect, 42f, 42f, board)
        canvas.drawRoundRect(boardRect, 42f, 42f, outer)
        canvas.drawRoundRect(RectF(boardRect.left + 20f, boardRect.top + 20f, boardRect.right - 20f, boardRect.bottom - 20f), 32f, 32f, inner)
    }

    private fun renderProblem(canvas: Canvas, scene: SceneSpec) {
        val question = scene.board.singleContent["question"].orEmpty()
        val choices = scene.board.content["choices"].orEmpty()
        val condition = inferCondition(scene)
        val fitBlocks = listOf(question) + choices + listOf("조건: $condition")
        val layout = AutoFitBoardEngine.fitForScene(scene.sceneId, scene.board.title, fitBlocks)

        val titlePaint = textPaint(layout.titleSize, warm, true, Paint.Align.CENTER)
        val questionPaint = textPaint(layout.questionSize, Color.WHITE, true)
        val choicePaint = textPaint(layout.choiceSize, chalk, true)
        val labelPaint = textPaint(max(34f, layout.choiceSize - 10f), warm, true, Paint.Align.CENTER)
        val conditionPaint = textPaint(max(40f, layout.choiceSize), warm, true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 160f, titlePaint)
        drawDivider(canvas, 208f)

        var y = 292f
        y = drawLines(canvas, wrapText(question, questionPaint, 820f), boardRect.left + PAD, y, questionPaint, layout.lineGap)
        y += layout.sectionGap

        val availableBottom = 1370f
        val baseRowHeight = when (layout.choiceSize) {
            in 0f..35f -> 100f
            in 35f..45f -> 114f
            else -> 128f
        }
        choices.forEach { choice ->
            val lines = wrapText(choice, choicePaint, 760f)
            val rowHeight = max(baseRowHeight, lines.size * (layout.choiceSize + layout.lineGap) + 50f)
            if (y + rowHeight > availableBottom) {
                // If content is extremely long, compress locally instead of clipping.
                val tinyPaint = textPaint(34f, chalk, true)
                y = drawChoiceRow(canvas, choice, y, tinyPaint, rowHeight = 104f)
                y += 12f
            } else {
                y = drawChoiceRow(canvas, choice, y, choicePaint, rowHeight = rowHeight)
                y += max(10f, layout.sectionGap - 12f)
            }
        }

        drawInfoBox(canvas, "조건", condition, labelPaint, conditionPaint, 1418f, 1685f)
        drawWarningIfNeeded(canvas, layout.warning)
    }

    private fun renderChoices(canvas: Canvas, scene: SceneSpec) {
        val choices = scene.board.content["choices"].orEmpty()
        val key = normalizeCondition(scene.board.singleContent["key_condition"].orEmpty())
        val layout = AutoFitBoardEngine.fitForScene(scene.sceneId, scene.board.title, choices + listOf(key))

        val titlePaint = textPaint(layout.titleSize, warm, true, Paint.Align.CENTER)
        val choicePaint = textPaint(layout.choiceSize + 8f, Color.WHITE, true)
        val conditionPaint = textPaint(max(42f, layout.choiceSize + 8f), warm, true, Paint.Align.CENTER)
        val labelPaint = textPaint(max(34f, layout.choiceSize - 8f), warm, true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 165f, titlePaint)
        drawDivider(canvas, 216f)

        var y = 340f
        choices.forEach { choice ->
            val rowHeight = max(116f, wrapText(choice, choicePaint, 760f).size * (choicePaint.textSize + layout.lineGap) + 54f)
            y = drawChoiceRow(canvas, choice, y, choicePaint, rowHeight = rowHeight)
            y += max(18f, layout.sectionGap)
        }
        drawInfoBox(canvas, "핵심 조건", key, labelPaint, conditionPaint, 1378f, 1648f)
        drawWarningIfNeeded(canvas, layout.warning)
    }

    private fun renderHint(canvas: Canvas, scene: SceneSpec) {
        val formula = scene.board.singleContent["formula"].orEmpty()
        val key = scene.board.singleContent["key_condition"].orEmpty()
        val hint = scene.board.singleContent["hint_text"].orEmpty()
        val layout = AutoFitBoardEngine.fitForScene(scene.sceneId, scene.board.title, listOf(formula, key, hint))

        val titlePaint = textPaint(layout.titleSize + 4f, warm, true, Paint.Align.CENTER)
        val formulaPaint = textPaint(max(84f, layout.answerSize + 18f), warm, true, Paint.Align.CENTER)
        val bodyPaint = textPaint(max(42f, layout.bodySize + 8f), Color.WHITE, true, Paint.Align.CENTER)
        val keyPaint = textPaint(max(58f, layout.bodySize + 22f), warm, true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 170f, titlePaint)
        drawDivider(canvas, 222f)
        drawCenterBox(canvas, formula, formulaPaint, 370f, 625f)
        drawCenterBox(canvas, key, keyPaint, 760f, 1000f, fill = panelGreen)
        drawCenteredMultiline(canvas, wrapText(hint, bodyPaint, 850f), boardRect.centerX(), 1202f, bodyPaint, 22f)
        drawWarningIfNeeded(canvas, layout.warning)
    }

    private fun renderSolution(canvas: Canvas, scene: SceneSpec) {
        val steps = scene.board.content["steps"].orEmpty()
        val conclusion = scene.board.singleContent["conclusion"].orEmpty().removePrefix("그래서 ").trim()
        val layout = AutoFitBoardEngine.fitForScene(scene.sceneId, scene.board.title, steps + listOf(conclusion))

        val titlePaint = textPaint(layout.titleSize, warm, true, Paint.Align.CENTER)
        val stepPaint = textPaint(layout.bodySize + 10f, Color.WHITE, true)
        val conclusionPaint = textPaint(max(40f, layout.bodySize + 8f), warm, true, Paint.Align.CENTER)
        val labelPaint = textPaint(max(32f, layout.bodySize - 4f), warm, true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 165f, titlePaint)
        drawDivider(canvas, 216f)

        var y = 360f
        steps.forEach { step ->
            val rowHeight = max(124f, wrapText(step, stepPaint, 760f).size * (stepPaint.textSize + layout.lineGap) + 58f)
            y = drawStepBox(canvas, step, y, stepPaint, height = rowHeight)
            y += max(16f, layout.sectionGap)
        }
        drawInfoBox(canvas, "결론", conclusion, labelPaint, conclusionPaint, 1378f, 1666f)
        drawWarningIfNeeded(canvas, layout.warning)
    }

    private fun renderAnswer(canvas: Canvas, scene: SceneSpec) {
        val answer = scene.board.singleContent["answer"].orEmpty()
        val answerText = scene.board.singleContent["answer_text"].orEmpty()
        val reason = scene.board.singleContent["reason"].orEmpty()
        val layout = AutoFitBoardEngine.fitForScene(scene.sceneId, scene.board.title, listOf(answer, answerText, reason))

        val titlePaint = textPaint(layout.titleSize + 6f, warm, true, Paint.Align.CENTER)
        val answerPaint = textPaint(max(90f, layout.answerSize + 26f), warm, true, Paint.Align.CENTER)
        val answerTextPaint = textPaint(max(56f, layout.bodySize + 22f), Color.WHITE, true, Paint.Align.CENTER)
        val reasonPaint = textPaint(max(38f, layout.bodySize + 8f), chalk, true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 170f, titlePaint)
        drawDivider(canvas, 222f)
        drawCenterBox(canvas, answer, answerPaint, 420f, 745f, fill = Color.rgb(52, 99, 72))
        drawCenteredMultiline(canvas, wrapText(answerText, answerTextPaint, 820f), boardRect.centerX(), 925f, answerTextPaint, 22f)
        drawCenteredMultiline(canvas, wrapText(reason, reasonPaint, 850f), boardRect.centerX(), 1198f, reasonPaint, 24f)
        drawWarningIfNeeded(canvas, layout.warning)
    }

    private fun renderSummary(canvas: Canvas, scene: SceneSpec) {
        val summary = scene.board.content["summary"].orEmpty()
        val cta = scene.board.singleContent["cta"].orEmpty()
        val layout = AutoFitBoardEngine.fitForScene(scene.sceneId, scene.board.title, summary + listOf(cta))

        val titlePaint = textPaint(layout.titleSize, warm, true, Paint.Align.CENTER)
        val summaryPaint = textPaint(layout.summarySize + 12f, Color.WHITE, true)
        val ctaPaint = textPaint(max(40f, layout.summarySize + 8f), warm, true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 165f, titlePaint)
        drawDivider(canvas, 216f)

        var y = 390f
        summary.forEach { item ->
            val rowHeight = max(132f, wrapText(item, summaryPaint, 760f).size * (summaryPaint.textSize + layout.lineGap) + 60f)
            y = drawStepBox(canvas, item, y, summaryPaint, height = rowHeight)
            y += max(22f, layout.sectionGap)
        }
        drawCenterBox(canvas, cta, ctaPaint, 1375f, 1615f, fill = Color.rgb(45, 91, 68))
        drawWarningIfNeeded(canvas, layout.warning)
    }

    private fun renderDefault(canvas: Canvas, scene: SceneSpec) {
        val blocks = collectTextBlocks(scene)
        val layout = AutoFitBoardEngine.fitForScene(scene.sceneId, scene.board.title, blocks)
        val titlePaint = textPaint(layout.titleSize, warm, true, Paint.Align.CENTER)
        val bodyPaint = textPaint(layout.bodySize, Color.WHITE, true)
        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 170f, titlePaint)
        drawDivider(canvas, 222f)
        drawLines(canvas, blocks.flatMap { wrapText(it, bodyPaint, 850f) }, boardRect.left + PAD, 340f, bodyPaint, layout.lineGap)
        drawWarningIfNeeded(canvas, layout.warning)
    }

    private fun drawChoiceRow(canvas: Canvas, text: String, y: Float, paint: Paint, rowHeight: Float): Float {
        val rect = RectF(boardRect.left + 66f, y - paint.textSize, boardRect.right - 66f, y - paint.textSize + rowHeight)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = panelGreen; style = Paint.Style.FILL }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = lineGreen; style = Paint.Style.STROKE; strokeWidth = 4f }
        canvas.drawRoundRect(rect, 28f, 28f, fill)
        canvas.drawRoundRect(rect, 28f, 28f, stroke)
        val lines = wrapText(text, paint, rect.width() - 70f)
        drawLines(canvas, lines, rect.left + 34f, rect.top + paint.textSize + 24f, paint, 8f)
        return rect.bottom
    }

    private fun drawStepBox(canvas: Canvas, text: String, y: Float, paint: Paint, height: Float): Float {
        val rect = RectF(boardRect.left + 66f, y - paint.textSize, boardRect.right - 66f, y - paint.textSize + height)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = panelGreen; style = Paint.Style.FILL }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = lineGreen; style = Paint.Style.STROKE; strokeWidth = 4f }
        canvas.drawRoundRect(rect, 28f, 28f, fill)
        canvas.drawRoundRect(rect, 28f, 28f, stroke)
        val lines = wrapText(text, paint, rect.width() - 70f)
        drawLines(canvas, lines, rect.left + 34f, rect.top + paint.textSize + 24f, paint, 8f)
        return rect.bottom
    }

    private fun drawInfoBox(canvas: Canvas, label: String, value: String, labelPaint: Paint, valuePaint: Paint, top: Float, bottom: Float) {
        val rect = RectF(boardRect.left + 82f, top, boardRect.right - 82f, bottom)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(36, 82, 62); style = Paint.Style.FILL }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = alertRed; style = Paint.Style.STROKE; strokeWidth = 5f }
        canvas.drawRoundRect(rect, 30f, 30f, fill)
        canvas.drawRoundRect(rect, 30f, 30f, stroke)
        drawCenteredText(canvas, label, rect.centerX(), top + 58f, labelPaint)
        drawCenteredMultiline(canvas, wrapText(value, valuePaint, rect.width() - 100f), rect.centerX(), top + 150f, valuePaint, 18f)
    }

    private fun drawCenterBox(canvas: Canvas, text: String, paint: Paint, top: Float, bottom: Float, fill: Int = panelGreen) {
        val rect = RectF(boardRect.left + 84f, top, boardRect.right - 84f, bottom)
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fill; style = Paint.Style.FILL }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = lineGreen; style = Paint.Style.STROKE; strokeWidth = 5f }
        canvas.drawRoundRect(rect, 34f, 34f, fillPaint)
        canvas.drawRoundRect(rect, 34f, 34f, strokePaint)
        drawCenteredMultiline(canvas, wrapText(text, paint, rect.width() - 90f), rect.centerX(), rect.centerY() - 18f, paint, 18f, verticallyCentered = true)
    }

    private fun drawDivider(canvas: Canvas, y: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(218, 199, 136); strokeWidth = 5f; style = Paint.Style.STROKE }
        canvas.drawLine(boardRect.left + 120f, y, boardRect.right - 120f, y, paint)
    }

    private fun textPaint(size: Float, color: Int, bold: Boolean, align: Paint.Align = Paint.Align.LEFT): Paint {
        return Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
            textAlign = align
        }
    }

    private fun drawLines(canvas: Canvas, lines: List<String>, x: Float, startY: Float, paint: Paint, gap: Float): Float {
        var y = startY
        lines.forEach { line ->
            canvas.drawText(line, x, y, paint)
            y += paint.textSize + gap
        }
        return y
    }

    private fun drawCenteredText(canvas: Canvas, text: String, x: Float, y: Float, paint: Paint) {
        val old = paint.textAlign
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(text, x, y, paint)
        paint.textAlign = old
    }

    private fun drawCenteredMultiline(
        canvas: Canvas,
        lines: List<String>,
        x: Float,
        startY: Float,
        paint: Paint,
        gap: Float,
        verticallyCentered: Boolean = false
    ): Float {
        val old = paint.textAlign
        paint.textAlign = Paint.Align.CENTER
        val lineHeight = paint.textSize + gap
        var y = if (verticallyCentered) {
            startY - ((lines.size - 1) * lineHeight / 2f) + paint.textSize / 2f
        } else {
            startY
        }
        lines.forEach { line ->
            canvas.drawText(line, x, y, paint)
            y += lineHeight
        }
        paint.textAlign = old
        return y
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        return AutoTextMeasurer.wrapTextByWidth(text, paint, maxWidth)
    }

    private fun normalizeCondition(raw: String): String {
        return when {
            raw.contains("저항") && raw.contains("일정") -> "R 일정"
            raw.contains("전압") && raw.contains("일정") -> "V 일정"
            raw.contains("전류") && raw.contains("일정") -> "I 일정"
            raw.isBlank() -> "R 일정"
            else -> raw
        }
    }

    private fun inferCondition(scene: SceneSpec): String {
        val q = scene.board.singleContent["question"].orEmpty()
        return when {
            q.contains("저항") || q.contains("R") -> "R 일정"
            q.contains("전압") || q.contains("V") -> "V 일정"
            q.contains("전류") || q.contains("I") -> "I 일정"
            else -> "핵심 조건"
        }
    }

    private fun collectTextBlocks(scene: SceneSpec): List<String> {
        val blocks = mutableListOf<String>()
        scene.board.singleContent.values.forEach { blocks.add(it) }
        scene.board.content.values.forEach { blocks.addAll(it) }
        return blocks.map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun drawWarningIfNeeded(canvas: Canvas, warning: String?) {
        if (warning.isNullOrBlank()) return
        val paint = textPaint(24f, Color.rgb(255, 210, 180), true, Paint.Align.CENTER)
        canvas.drawText(warning, boardRect.centerX(), 1780f, paint)
    }

    private fun drawFooter(canvas: Canvas, scene: SceneSpec) {
        val paint = textPaint(26f, Color.rgb(82, 70, 139), true, Paint.Align.CENTER)
        canvas.drawText("SceneSlate · ${scene.sceneId} · ${scene.sceneTitle}", WIDTH / 2f, 1880f, paint)
    }

    private fun createImageFileName(sceneId: String): String {
        val suffix = when (sceneId) {
            "SC01" -> "problem"
            "SC02" -> "choices"
            "SC03" -> "hint"
            "SC04" -> "solution"
            "SC05" -> "answer"
            "SC06" -> "summary"
            else -> "scene"
        }
        return "${sceneId}_$suffix.png"
    }
}
