SceneSlate v0.2.5 - enlarged preview and readable board PNG update
