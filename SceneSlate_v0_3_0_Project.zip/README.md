SceneSlate v0.3.0 - dark academy gothic board theme prototype
