package com.sceneslate.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sceneslate.studio.ui.SceneSlateMainScreen
import com.sceneslate.studio.ui.SceneSlateViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: SceneSlateViewModel = viewModel()
            SceneSlateMainScreen(viewModel = viewModel)
        }
    }
}
