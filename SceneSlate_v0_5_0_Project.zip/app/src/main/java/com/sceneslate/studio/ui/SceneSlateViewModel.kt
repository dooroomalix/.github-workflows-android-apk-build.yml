package com.sceneslate.studio.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sceneslate.studio.exporter.SceneSlateProjectExporter
import com.sceneslate.studio.generator.SceneSpecGenerator
import com.sceneslate.studio.model.EpisodeInput
import com.sceneslate.studio.sample.SampleEpisodeFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

private const val APP_VERSION_LABEL = "SceneSlate v0.5.0"

data class SampleCheckResult(
    val sampleName: String,
    val projectPath: String,
    val pass: Boolean,
    val qualityPass: Boolean,
    val projectReady: Boolean,
    val imageCount: Int,
    val missingImages: List<String>,
    val tinyImages: List<String>,
    val representativeImagePath: String,
    val qualityReport: String
)

data class SceneSlateUiState(
    val status: String = "대기",
    val autoReviewResult: String = "대기",
    val autoReviewText: String = "앱을 열면 옴 샘플과 긴 문제 샘플을 자동 생성하고 자체 검수합니다.",
    val representativeImagePath: String = "",
    val representativeImageName: String = "",
    val currentSampleName: String = "자동 마일스톤 검수",
    val sampleReports: List<SampleCheckResult> = emptyList(),
    val detailReportText: String = "",
    val errorMessage: String = ""
)

class SceneSlateViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(SceneSlateUiState())
    val uiState: StateFlow<SceneSlateUiState> = _uiState

    fun runMilestoneAutoCheck(context: Context) {
        viewModelScope.launch {
            try {
                _uiState.value = SceneSlateUiState(
                    status = "자동 검수 중",
                    autoReviewResult = "검수 중",
                    autoReviewText = "옴 샘플과 긴 문제 샘플을 자동 생성하고 PNG 12장, 품질 리포트, 대표 화면을 검수 중입니다."
                )

                val rootDir = File(context.filesDir, "SceneSlateProjects")
                val ohm = generateAndCheck(
                    rootDir = rootDir,
                    episodeInput = SampleEpisodeFactory.createOhmsLawEpisode(),
                    sampleName = "옴의 법칙"
                )
                val long = generateAndCheck(
                    rootDir = rootDir,
                    episodeInput = SampleEpisodeFactory.createLongQuestionEpisode(),
                    sampleName = "긴 문제 자동 맞춤"
                )
                val reports = listOf(ohm, long)
                val pass = reports.all { it.pass }
                val representative = long.representativeImagePath.ifBlank { ohm.representativeImagePath }
                val representativeName = representative.substringAfterLast('/')

                _uiState.value = SceneSlateUiState(
                    status = "완료",
                    autoReviewResult = if (pass) "PASS" else "FAIL",
                    autoReviewText = buildMilestoneSummary(reports, pass),
                    representativeImagePath = representative,
                    representativeImageName = representativeName,
                    currentSampleName = "긴 문제 자동 맞춤",
                    sampleReports = reports,
                    detailReportText = buildDetailReport(reports),
                    errorMessage = ""
                )
            } catch (e: Exception) {
                _uiState.value = SceneSlateUiState(
                    status = "실패",
                    autoReviewResult = "FAIL",
                    autoReviewText = "자동 마일스톤 검수 중 오류가 발생했습니다.",
                    errorMessage = e.message ?: "알 수 없는 오류"
                )
            }
        }
    }

    fun generateOhmsLawSample(context: Context) {
        runSingleCheck(context, SampleEpisodeFactory.createOhmsLawEpisode(), "옴의 법칙")
    }

    fun generateLongQuestionSample(context: Context) {
        runSingleCheck(context, SampleEpisodeFactory.createLongQuestionEpisode(), "긴 문제 자동 맞춤")
    }

    private fun runSingleCheck(context: Context, episodeInput: EpisodeInput, sampleName: String) {
        viewModelScope.launch {
            try {
                _uiState.value = SceneSlateUiState(
                    status = "자동 검수 중",
                    autoReviewResult = "검수 중",
                    autoReviewText = "$sampleName 샘플을 자동 생성하고 검수 중입니다.",
                    currentSampleName = sampleName
                )
                val result = generateAndCheck(File(context.filesDir, "SceneSlateProjects"), episodeInput, sampleName)
                _uiState.value = SceneSlateUiState(
                    status = "완료",
                    autoReviewResult = if (result.pass) "PASS" else "FAIL",
                    autoReviewText = buildMilestoneSummary(listOf(result), result.pass),
                    representativeImagePath = result.representativeImagePath,
                    representativeImageName = result.representativeImagePath.substringAfterLast('/'),
                    currentSampleName = sampleName,
                    sampleReports = listOf(result),
                    detailReportText = buildDetailReport(listOf(result))
                )
            } catch (e: Exception) {
                _uiState.value = SceneSlateUiState(
                    status = "실패",
                    autoReviewResult = "FAIL",
                    autoReviewText = "$sampleName 자동 검수 중 오류가 발생했습니다.",
                    currentSampleName = sampleName,
                    errorMessage = e.message ?: "알 수 없는 오류"
                )
            }
        }
    }

    private fun generateAndCheck(
        rootDir: File,
        episodeInput: EpisodeInput,
        sampleName: String
    ): SampleCheckResult {
        val sceneSpecDocument = SceneSpecGenerator.generate(episodeInput)
        val result = SceneSlateProjectExporter.exportProject(episodeInput, sceneSpecDocument, rootDir)

        val qualityReportFile = File(result.projectDir, "quality_report.txt")
        val qualityReport = qualityReportFile.readText(Charsets.UTF_8)
        val imagesDir = File(result.projectDir, "images")
        val imageFiles = imagesDir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() == "png" }
            ?.sortedBy { it.name }
            .orEmpty()

        val expected = listOf(
            "SC01_problem.png",
            "SC02_choices.png",
            "SC03_hint.png",
            "SC04_solution.png",
            "SC05_answer.png",
            "SC06_summary.png"
        )
        val names = imageFiles.map { it.name }.toSet()
        val missing = expected.filter { it !in names }
        val tiny = imageFiles.filter { it.length() < 1_000L }.map { it.name }
        val qualityPass = qualityReport.contains("Final Result: PASS")
        val projectReady = File(result.projectDir, "scenes/scenespec.json").exists() &&
            File(result.projectDir, "tts/batch_input.tsv").exists() &&
            File(result.projectDir, "subtitles/subtitle_preview.txt").exists() &&
            File(result.projectDir, "board/board_preview.json").exists()
        val sc01Path = imageFiles.firstOrNull { it.name == "SC01_problem.png" }?.absolutePath.orEmpty()
        val pass = qualityPass && projectReady && missing.isEmpty() && tiny.isEmpty() && sc01Path.isNotBlank()

        return SampleCheckResult(
            sampleName = sampleName,
            projectPath = result.projectDir.absolutePath,
            pass = pass,
            qualityPass = qualityPass,
            projectReady = projectReady,
            imageCount = imageFiles.size,
            missingImages = missing,
            tinyImages = tiny,
            representativeImagePath = sc01Path,
            qualityReport = qualityReport
        )
    }

    private fun buildMilestoneSummary(reports: List<SampleCheckResult>, pass: Boolean): String {
        val totalImages = reports.sumOf { it.imageCount }
        val passedCount = reports.count { it.pass }
        return buildString {
            appendLine("자동 검수: ${if (pass) "PASS" else "FAIL"}")
            appendLine("버전: $APP_VERSION_LABEL")
            appendLine("샘플 통과: $passedCount/${reports.size}")
            appendLine("PNG 이미지: $totalImages/${reports.size * 6}")
            appendLine("대표 화면: SC01 자동 표시")
            appendLine("사용자 확인: PASS와 대표 화면 1장만 보면 됩니다.")
        }.trimEnd()
    }

    private fun buildDetailReport(reports: List<SampleCheckResult>): String {
        return buildString {
            appendLine("SceneSlate Milestone Auto Check")
            appendLine("Version: $APP_VERSION_LABEL")
            appendLine()
            reports.forEach { report ->
                appendLine("[${report.sampleName}]")
                appendLine("Result: ${if (report.pass) "PASS" else "FAIL"}")
                appendLine("Quality Report: ${if (report.qualityPass) "PASS" else "FAIL"}")
                appendLine("Project Data: ${if (report.projectReady) "OK" else "MISSING"}")
                appendLine("PNG Images: ${report.imageCount}/6")
                appendLine("Representative SC01: ${if (report.representativeImagePath.isNotBlank()) "OK" else "MISSING"}")
                if (report.missingImages.isNotEmpty()) appendLine("Missing: ${report.missingImages.joinToString()}")
                if (report.tinyImages.isNotEmpty()) appendLine("Tiny: ${report.tinyImages.joinToString()}")
                appendLine("Path: ${report.projectPath}")
                appendLine()
            }
        }.trimEnd()
    }
}
