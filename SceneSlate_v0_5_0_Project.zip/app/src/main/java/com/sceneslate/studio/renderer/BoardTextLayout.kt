package com.sceneslate.studio.renderer

data class BoardTextLayout(
    val titleSize: Float,
    val questionSize: Float,
    val choiceSize: Float,
    val bodySize: Float,
    val answerSize: Float,
    val summarySize: Float,
    val sectionGap: Float,
    val lineGap: Float,
    val warning: String? = null
)

object BoardTextLayoutDefaults {
    fun normal(): BoardTextLayout = BoardTextLayout(
        titleSize = 78f,
        questionSize = 58f,
        choiceSize = 52f,
        bodySize = 52f,
        answerSize = 92f,
        summarySize = 52f,
        sectionGap = 34f,
        lineGap = 16f
    )

    fun compact(): BoardTextLayout = BoardTextLayout(
        titleSize = 70f,
        questionSize = 48f,
        choiceSize = 44f,
        bodySize = 44f,
        answerSize = 78f,
        summarySize = 44f,
        sectionGap = 24f,
        lineGap = 12f
    )

    fun minimumReadable(): BoardTextLayout = BoardTextLayout(
        titleSize = 62f,
        questionSize = 38f,
        choiceSize = 34f,
        bodySize = 34f,
        answerSize = 62f,
        summarySize = 34f,
        sectionGap = 16f,
        lineGap = 8f,
        warning = "텍스트가 길어 최소 가독성 기준에 가까움"
    )
}
