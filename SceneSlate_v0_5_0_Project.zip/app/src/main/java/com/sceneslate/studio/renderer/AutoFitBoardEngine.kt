package com.sceneslate.studio.renderer

import android.graphics.Paint
import android.graphics.Typeface

object AutoFitBoardEngine {
    private const val BOARD_CONTENT_HEIGHT = 1420f
    private const val BOARD_TEXT_WIDTH = 790f

    fun fitForScene(sceneId: String, title: String, textBlocks: List<String>): BoardTextLayout {
        val candidates = listOf(
            BoardTextLayoutDefaults.normal(),
            BoardTextLayoutDefaults.compact(),
            BoardTextLayoutDefaults.minimumReadable()
        )
        return candidates.firstOrNull { fits(sceneId, title, textBlocks, it) }
            ?: BoardTextLayoutDefaults.minimumReadable().copy(
                warning = "텍스트가 너무 길어 칠판 가독성이 낮을 수 있음"
            )
    }

    private fun fits(sceneId: String, title: String, textBlocks: List<String>, layout: BoardTextLayout): Boolean {
        return estimateHeight(sceneId, title, textBlocks, layout) <= BOARD_CONTENT_HEIGHT
    }

    private fun estimateHeight(sceneId: String, title: String, textBlocks: List<String>, layout: BoardTextLayout): Float {
        var height = layout.titleSize + layout.sectionGap * 2f
        textBlocks.forEachIndexed { index, block ->
            val size = when {
                sceneId == "SC05" && index == 0 -> layout.answerSize
                sceneId == "SC01" && index == 0 -> layout.questionSize
                sceneId == "SC06" -> layout.summarySize
                sceneId == "SC01" && index in 1..4 -> layout.choiceSize
                sceneId == "SC02" && index in 0..3 -> layout.choiceSize
                else -> layout.bodySize
            }
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val lines = AutoTextMeasurer.wrapTextByWidth(block, paint, BOARD_TEXT_WIDTH)
            val blockHeight = lines.size * (size + layout.lineGap) + layout.sectionGap
            height += if (sceneId == "SC01" && index in 1..4) blockHeight + 20f else blockHeight
        }
        return height
    }
}
