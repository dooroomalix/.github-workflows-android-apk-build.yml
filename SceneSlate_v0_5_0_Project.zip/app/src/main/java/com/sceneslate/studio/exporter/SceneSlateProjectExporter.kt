package com.sceneslate.studio.exporter

import com.sceneslate.studio.model.EpisodeInput
import com.sceneslate.studio.model.SceneSpecDocument
import com.sceneslate.studio.quality.QualityReportGenerator
import com.sceneslate.studio.renderer.BoardImageRenderer
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

data class SceneSlateExportResult(
    val projectDir: File,
    val generatedFiles: List<File>
)

object SceneSlateProjectExporter {
    private val json = Json { prettyPrint = true; encodeDefaults = true }

    fun exportProject(
        episodeInput: EpisodeInput,
        sceneSpecDocument: SceneSpecDocument,
        rootDir: File
    ): SceneSlateExportResult {
        val projectDir = createProjectDir(rootDir, episodeInput.episode.episodeId, episodeInput.episode.title)
        val generatedFiles = mutableListOf<File>()

        generatedFiles.add(writeEpisodeInputJson(episodeInput, projectDir))
        generatedFiles.add(writeEpisodeInputTsv(episodeInput, projectDir))
        generatedFiles.add(writeSceneSpecJson(sceneSpecDocument, projectDir))
        generatedFiles.add(TtsTsvFileWriter.writeToFile(sceneSpecDocument, projectDir))
        generatedFiles.addAll(SubtitleFileWriter.writeToFiles(sceneSpecDocument, projectDir))
        generatedFiles.add(BoardPreviewFileWriter.writeToFile(sceneSpecDocument, projectDir))
        generatedFiles.addAll(BoardImageRenderer.renderAll(sceneSpecDocument, projectDir))
        generatedFiles.add(ProjectInfoFileWriter.writeToFile(sceneSpecDocument, projectDir))
        generatedFiles.add(writeQualityReport(sceneSpecDocument, projectDir))

        return SceneSlateExportResult(projectDir = projectDir, generatedFiles = generatedFiles)
    }

    private fun createProjectDir(rootDir: File, episodeId: String, title: String): File {
        if (!rootDir.exists()) rootDir.mkdirs()
        val safeTitle = sanitizeFileName(title)
        val projectDir = File(rootDir, "${episodeId}_$safeTitle")
        if (!projectDir.exists()) projectDir.mkdirs()
        return projectDir
    }

    private fun writeEpisodeInputJson(episodeInput: EpisodeInput, projectDir: File): File {
        val inputDir = File(projectDir, "input")
        inputDir.mkdirs()
        val file = File(inputDir, "episode_input.json")
        file.writeText(json.encodeToString(episodeInput), Charsets.UTF_8)
        return file
    }

    private fun writeEpisodeInputTsv(episodeInput: EpisodeInput, projectDir: File): File {
        val inputDir = File(projectDir, "input")
        inputDir.mkdirs()
        val file = File(inputDir, "episode_input.tsv")
        file.writeText(EpisodeInputTsvExporter.export(episodeInput), Charsets.UTF_8)
        return file
    }

    private fun writeSceneSpecJson(sceneSpecDocument: SceneSpecDocument, projectDir: File): File {
        val scenesDir = File(projectDir, "scenes")
        scenesDir.mkdirs()
        val file = File(scenesDir, "scenespec.json")
        file.writeText(json.encodeToString(sceneSpecDocument), Charsets.UTF_8)
        return file
    }

    private fun writeQualityReport(sceneSpecDocument: SceneSpecDocument, projectDir: File): File {
        val file = File(projectDir, "quality_report.txt")
        file.writeText(QualityReportGenerator.generate(sceneSpecDocument, projectDir), Charsets.UTF_8)
        return file
    }

    private fun sanitizeFileName(value: String): String {
        return value.trim()
            .replace(Regex("""[\\/:*?"<>|]"""), "_")
            .replace(Regex("""\s+"""), "_")
            .take(40)
            .ifBlank { "untitled" }
    }
}
