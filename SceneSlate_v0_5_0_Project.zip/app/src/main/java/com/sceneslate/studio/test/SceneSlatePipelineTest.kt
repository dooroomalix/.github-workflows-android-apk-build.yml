package com.sceneslate.studio.test

import com.sceneslate.studio.exporter.SceneSlateProjectExporter
import com.sceneslate.studio.generator.SceneSpecGenerator
import com.sceneslate.studio.sample.SampleEpisodeFactory
import java.io.File

object SceneSlatePipelineTest {
    fun runTest(rootDir: File): File {
        val episodeInput = SampleEpisodeFactory.createOhmsLawEpisode()
        val sceneSpecDocument = SceneSpecGenerator.generate(episodeInput)
        val result = SceneSlateProjectExporter.exportProject(
            episodeInput = episodeInput,
            sceneSpecDocument = sceneSpecDocument,
            rootDir = rootDir
        )
        return result.projectDir
    }
}
