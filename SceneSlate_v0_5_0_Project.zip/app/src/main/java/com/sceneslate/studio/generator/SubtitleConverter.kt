package com.sceneslate.studio.generator

object SubtitleConverter {
    private val validPauseRegex = Regex("""\[pause=(300|500|700|1000)\]""")
    private val anyPauseLikeRegex = Regex("""\[pause[^\]]*\]""")

    fun toSubtitleText(ttsText: String): String {
        require(ttsText.isNotBlank()) { "TTS text is empty." }

        val invalidPauseTags = anyPauseLikeRegex.findAll(ttsText)
            .map { it.value }
            .filter { !validPauseRegex.matches(it) }
            .toList()

        require(invalidPauseTags.isEmpty()) {
            "Invalid pause tag(s): ${invalidPauseTags.joinToString(", ")}"
        }

        return ttsText
            .replace(validPauseRegex, "\n")
            .replace(Regex("""[ \t]+"""), " ")
            .replace(Regex(""" *\n *"""), "\n")
            .replace(Regex("""\n{2,}"""), "\n")
            .trim()
    }

    fun matchesTts(ttsText: String, subtitleText: String): Boolean {
        val normalizedTts = ttsText
            .replace(validPauseRegex, "")
            .replace(Regex("""\s+"""), "")

        val normalizedSubtitle = subtitleText
            .replace(Regex("""\s+"""), "")

        return normalizedTts == normalizedSubtitle
    }

    fun findInvalidPauseTags(text: String): List<String> {
        return anyPauseLikeRegex.findAll(text)
            .map { it.value }
            .filter { !validPauseRegex.matches(it) }
            .toList()
    }
}
