package com.sceneslate.studio.renderer

import android.graphics.Paint

object AutoTextMeasurer {
    fun wrapTextByWidth(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isBlank()) return emptyList()
        val result = mutableListOf<String>()

        text.split("\n").forEach { paragraphRaw ->
            val paragraph = paragraphRaw.trim()
            if (paragraph.isBlank()) return@forEach

            val words = paragraph.split(" ").filter { it.isNotBlank() }
            if (words.size > 1) {
                var line = ""
                words.forEach { word ->
                    val candidate = if (line.isBlank()) word else "$line $word"
                    if (paint.measureText(candidate) <= maxWidth) {
                        line = candidate
                    } else {
                        if (line.isNotBlank()) result.add(line)
                        if (paint.measureText(word) <= maxWidth) {
                            line = word
                        } else {
                            result.addAll(forceBreak(word, paint, maxWidth))
                            line = ""
                        }
                    }
                }
                if (line.isNotBlank()) result.add(line)
            } else {
                result.addAll(forceBreak(paragraph, paint, maxWidth))
            }
        }

        return result.ifEmpty { listOf(text) }
    }

    private fun forceBreak(text: String, paint: Paint, maxWidth: Float): List<String> {
        val result = mutableListOf<String>()
        var current = ""
        text.forEach { ch ->
            val candidate = current + ch
            if (paint.measureText(candidate) <= maxWidth) {
                current = candidate
            } else {
                if (current.isNotBlank()) result.add(current)
                current = ch.toString()
            }
        }
        if (current.isNotBlank()) result.add(current)
        return result
    }
}
