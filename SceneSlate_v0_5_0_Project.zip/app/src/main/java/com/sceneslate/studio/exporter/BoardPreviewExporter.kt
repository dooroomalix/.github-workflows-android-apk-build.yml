package com.sceneslate.studio.exporter

import com.sceneslate.studio.model.BoardPreviewDocument
import com.sceneslate.studio.model.BoardPreviewItem
import com.sceneslate.studio.model.SceneSpec
import com.sceneslate.studio.model.SceneSpecDocument
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

object BoardPreviewExporter {
    private val json = Json { prettyPrint = true; encodeDefaults = true }

    fun exportDocument(document: SceneSpecDocument): BoardPreviewDocument {
        validate(document)
        val boards = document.scenes.map { scene ->
            BoardPreviewItem(
                sceneId = scene.sceneId,
                layout = scene.board.layout,
                title = scene.board.title,
                textBlocks = collectTextBlocks(scene),
                emphasis = scene.board.emphasis
            )
        }
        return BoardPreviewDocument(
            episodeId = document.episode.episodeId,
            title = document.episode.title,
            boards = boards
        )
    }

    fun exportJson(document: SceneSpecDocument): String = json.encodeToString(exportDocument(document))

    private fun collectTextBlocks(scene: SceneSpec): List<String> {
        val blocks = mutableListOf<String>()
        when (scene.sceneId) {
            "SC01" -> {
                scene.board.singleContent["question"]?.let { blocks.add(it) }
                scene.board.content["choices"]?.let { blocks.addAll(it) }
            }
            "SC02" -> {
                scene.board.content["choices"]?.let { blocks.addAll(it) }
                scene.board.singleContent["key_condition"]?.let { blocks.add("조건: $it") }
            }
            "SC03" -> {
                scene.board.singleContent["formula"]?.let { blocks.add(it) }
                scene.board.singleContent["key_condition"]?.let { blocks.add(it) }
                scene.board.singleContent["hint_text"]?.let { blocks.add(it) }
            }
            "SC04" -> {
                scene.board.content["steps"]?.let { blocks.addAll(it) }
                scene.board.singleContent["conclusion"]?.let { blocks.add("결론: $it") }
            }
            "SC05" -> {
                scene.board.singleContent["answer"]?.let { blocks.add(it) }
                scene.board.singleContent["answer_text"]?.let { blocks.add(it) }
                scene.board.singleContent["reason"]?.let { blocks.add(it) }
            }
            "SC06" -> {
                scene.board.content["summary"]?.let { blocks.addAll(it) }
                scene.board.singleContent["cta"]?.let { blocks.add(it) }
            }
            else -> {
                scene.board.singleContent.values.forEach { blocks.add(it) }
                scene.board.content.values.forEach { blocks.addAll(it) }
            }
        }
        return blocks.map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun validate(document: SceneSpecDocument) {
        require(document.scenes.size == 6) { "SceneSpecDocument must contain exactly 6 scenes." }
        val expectedSceneIds = listOf("SC01", "SC02", "SC03", "SC04", "SC05", "SC06")
        val actualSceneIds = document.scenes.map { it.sceneId }
        require(actualSceneIds == expectedSceneIds) { "Scene IDs must be SC01~SC06 in order. actual=$actualSceneIds" }

        document.scenes.forEach { scene ->
            require(scene.board.layout.isNotBlank()) { "${scene.sceneId} board.layout is empty." }
            require(scene.board.title.isNotBlank()) { "${scene.sceneId} board.title is empty." }
            require(collectTextBlocks(scene).isNotEmpty()) { "${scene.sceneId} board textBlocks are empty." }
        }

        validateScene01(document)
        validateScene05(document)
        validateScene06(document)
    }

    private fun validateScene01(document: SceneSpecDocument) {
        val scene = document.scenes.first { it.sceneId == "SC01" }
        val question = scene.board.singleContent["question"]
        val choices = scene.board.content["choices"]
        require(!question.isNullOrBlank()) { "SC01 must contain board question." }
        require(choices != null && choices.size == 4) { "SC01 must contain exactly 4 choices." }
    }

    private fun validateScene05(document: SceneSpecDocument) {
        val scene = document.scenes.first { it.sceneId == "SC05" }
        require(!scene.board.singleContent["answer"].isNullOrBlank()) { "SC05 must contain answer." }
        require(!scene.board.singleContent["answer_text"].isNullOrBlank()) { "SC05 must contain answer_text." }
        require(!scene.board.singleContent["reason"].isNullOrBlank()) { "SC05 must contain answer reason." }
    }

    private fun validateScene06(document: SceneSpecDocument) {
        val scene = document.scenes.first { it.sceneId == "SC06" }
        val summary = scene.board.content["summary"]
        require(summary != null && summary.size == 3) { "SC06 must contain exactly 3 summary lines." }
    }
}

object BoardPreviewFileWriter {
    fun writeToFile(document: SceneSpecDocument, outputDir: File): File {
        val boardDir = File(outputDir, "board")
        if (!boardDir.exists()) boardDir.mkdirs()
        val file = File(boardDir, "board_preview.json")
        file.writeText(BoardPreviewExporter.exportJson(document), Charsets.UTF_8)
        return file
    }
}
