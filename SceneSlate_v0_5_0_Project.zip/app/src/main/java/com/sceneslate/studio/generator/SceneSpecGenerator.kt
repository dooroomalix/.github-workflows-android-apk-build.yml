package com.sceneslate.studio.generator

import com.sceneslate.studio.model.*

object SceneSpecGenerator {

    fun generate(input: EpisodeInput): SceneSpecDocument {
        validateEpisodeInput(input)

        val scenes = listOf(
            createScene01ProblemIntro(input),
            createScene02ChoiceFocus(input),
            createScene03Hint(input),
            createScene04Solution(input),
            createScene05AnswerReveal(input),
            createScene06Summary(input)
        )

        return SceneSpecDocument(
            project = input.project,
            episode = input.episode,
            character = input.character,
            globalRules = GlobalRules(),
            scenes = scenes
        )
    }

    private fun createScene01ProblemIntro(input: EpisodeInput): SceneSpec {
        val question = makeBoardQuestion(input.questionSet.question)
        val choices = makeNumberedChoices(input.questionSet.choices)
        val tts = "좋아. [pause=300] 리리스 퀴즈 시작이야. [pause=500] 칠판을 보고, 정답을 골라봐."

        return SceneSpec(
            sceneId = "SC01",
            sceneType = SceneTypes.PROBLEM_INTRO,
            sceneTitle = "문제 제시",
            board = BoardSpec(
                layout = BoardLayouts.PROBLEM_CHOICES,
                title = "5초 안에 맞혀봐",
                singleContent = mapOf("question" to question),
                content = mapOf("choices" to choices)
            ),
            lilith = LilithSpec(
                pose = LilithPoses.STANDING_POINTING_BOARD,
                action = LilithActions.POINT_TO_QUESTION,
                expression = LilithExpressions.CALM_CHALLENGE
            ),
            voice = VoiceSpec(
                emotion = VoiceEmotions.CALM_CHALLENGE,
                speed = 0.95,
                pitch = -1,
                ttsText = tts
            ),
            subtitle = SubtitleSpec(text = SubtitleConverter.toSubtitleText(tts)),
            timing = TimingSpec(targetDurationSec = 6),
            camera = CameraSpec(motion = CameraMotions.SLIGHT_ZOOM_IN),
            qualityCheck = QualityCheckSpec(mustShowChoices4 = true)
        )
    }

    private fun createScene02ChoiceFocus(input: EpisodeInput): SceneSpec {
        val shortChoices = makeShortChoices(input.questionSet.choices)
        val keyCondition = extractKeyCondition(input)
        val tts = "잠깐. [pause=500] 바로 찍지 마. [pause=300] 보기 차이를 먼저 확인해."

        return SceneSpec(
            sceneId = "SC02",
            sceneType = SceneTypes.CHOICE_FOCUS,
            sceneTitle = "보기 확인",
            board = BoardSpec(
                layout = BoardLayouts.CHOICE_FOCUS,
                title = "바로 찍지 마",
                singleContent = mapOf("key_condition" to keyCondition),
                content = mapOf("choices" to shortChoices),
                emphasis = listOf(BoardEmphasis(type = "underline", target = keyCondition))
            ),
            lilith = LilithSpec(
                pose = LilithPoses.SIDE_POINTING_CHOICES,
                action = LilithActions.COMPARE_CHOICES,
                expression = LilithExpressions.TEACHER_FOCUS
            ),
            voice = VoiceSpec(
                emotion = VoiceEmotions.TEACHER_FOCUS,
                speed = 0.93,
                pitch = -1,
                ttsText = tts
            ),
            subtitle = SubtitleSpec(text = SubtitleConverter.toSubtitleText(tts)),
            timing = TimingSpec(targetDurationSec = 6),
            camera = CameraSpec(motion = CameraMotions.BOARD_FOCUS_PAN),
            qualityCheck = QualityCheckSpec(mustShowChoices4 = true)
        )
    }

    private fun createScene03Hint(input: EpisodeInput): SceneSpec {
        val formula = input.learning.coreFormula.ifBlank { "핵심 조건" }
        val keyCondition = extractKeyCondition(input)
        val boardHint = makeBoardHint(input)
        val tts = "힌트 줄게. [pause=500] 핵심은… [pause=700] ${input.learning.hint}"

        return SceneSpec(
            sceneId = "SC03",
            sceneType = SceneTypes.HINT,
            sceneTitle = "힌트",
            board = BoardSpec(
                layout = BoardLayouts.HINT_FOCUS,
                title = "힌트",
                singleContent = mapOf(
                    "formula" to formula,
                    "key_condition" to keyCondition,
                    "hint_text" to boardHint
                ),
                emphasis = listOf(
                    BoardEmphasis(type = "circle", target = keyCondition),
                    BoardEmphasis(type = "underline", target = formula)
                )
            ),
            lilith = LilithSpec(
                pose = LilithPoses.LEAN_POINTING_KEY,
                action = LilithActions.UNDERLINE_KEY_CONDITION,
                expression = LilithExpressions.SECRET_HINT
            ),
            voice = VoiceSpec(
                emotion = VoiceEmotions.LOW_HINT,
                speed = 0.88,
                pitch = -2,
                ttsText = tts
            ),
            subtitle = SubtitleSpec(text = SubtitleConverter.toSubtitleText(tts)),
            timing = TimingSpec(targetDurationSec = 7),
            camera = CameraSpec(motion = CameraMotions.SLOW_ZOOM_IN),
            qualityCheck = QualityCheckSpec(mustShowChoices4 = false)
        )
    }

    private fun createScene04Solution(input: EpisodeInput): SceneSpec {
        val steps = normalizeSolutionSteps(input.learning.solutionSteps)
        val conclusion = makeSolutionConclusion(input)
        val tts = "먼저 조건을 정리하고, [pause=300] 공식을 보면 답이 보여. [pause=500] $conclusion"

        return SceneSpec(
            sceneId = "SC04",
            sceneType = SceneTypes.SOLUTION,
            sceneTitle = "풀이",
            board = BoardSpec(
                layout = BoardLayouts.SOLUTION_STEPS,
                title = "풀이 포인트",
                singleContent = mapOf("conclusion" to conclusion),
                content = mapOf("steps" to steps),
                emphasis = listOf(BoardEmphasis(type = "box", target = steps.lastOrNull() ?: conclusion))
            ),
            lilith = LilithSpec(
                pose = LilithPoses.WRITING_ON_BOARD,
                action = LilithActions.WRITE_SOLUTION_STEPS,
                expression = LilithExpressions.FOCUSED_EXPLAIN
            ),
            voice = VoiceSpec(
                emotion = VoiceEmotions.CLEAR_EXPLAIN,
                speed = 0.92,
                pitch = -1,
                ttsText = tts
            ),
            subtitle = SubtitleSpec(text = SubtitleConverter.toSubtitleText(tts)),
            timing = TimingSpec(targetDurationSec = 9),
            camera = CameraSpec(motion = CameraMotions.STATIC),
            qualityCheck = QualityCheckSpec(mustShowChoices4 = false)
        )
    }

    private fun createScene05AnswerReveal(input: EpisodeInput): SceneSpec {
        val answerNumber = toKoreanChoiceNumber(input.questionSet.answerIndex)
        val answerText = input.questionSet.answerText
        val shortReason = makeShortAnswerReason(input)
        val tts = "자, 정답 공개. [pause=700] 정답은… [pause=700] ${input.questionSet.answerIndex}번. $shortReason"

        return SceneSpec(
            sceneId = "SC05",
            sceneType = SceneTypes.ANSWER_REVEAL,
            sceneTitle = "정답 공개",
            board = BoardSpec(
                layout = BoardLayouts.ANSWER_LARGE,
                title = "정답 공개",
                singleContent = mapOf(
                    "answer" to "정답 $answerNumber",
                    "answer_text" to answerText,
                    "reason" to makeBoardAnswerReason(input)
                ),
                emphasis = listOf(BoardEmphasis(type = "circle", target = "정답 $answerNumber"))
            ),
            lilith = LilithSpec(
                pose = LilithPoses.CONFIDENT_POINTING_ANSWER,
                action = LilithActions.CIRCLE_ANSWER,
                expression = LilithExpressions.CONFIDENT_REVEAL
            ),
            voice = VoiceSpec(
                emotion = VoiceEmotions.CONFIDENT_REVEAL,
                speed = 0.90,
                pitch = 0,
                ttsText = tts
            ),
            subtitle = SubtitleSpec(text = SubtitleConverter.toSubtitleText(tts)),
            timing = TimingSpec(targetDurationSec = 7),
            camera = CameraSpec(motion = CameraMotions.ANSWER_POP_ZOOM),
            qualityCheck = QualityCheckSpec(mustShowChoices4 = false)
        )
    }

    private fun createScene06Summary(input: EpisodeInput): SceneSpec {
        val summary = normalizeSummary(input.learning.summary)
        val cta = input.style.cta
        val tts = "오늘 핵심은 세 가지야. [pause=500] ${summary[0]}하고, [pause=300] ${summary[2]}. [pause=500] $cta"

        return SceneSpec(
            sceneId = "SC06",
            sceneType = SceneTypes.SUMMARY,
            sceneTitle = "핵심 요약",
            board = BoardSpec(
                layout = BoardLayouts.SUMMARY_THREE,
                title = "오늘의 핵심",
                singleContent = mapOf("cta" to cta),
                content = mapOf("summary" to listOf(
                    "1. ${summary[0]}",
                    "2. ${summary[1]}",
                    "3. ${summary[2]}"
                ))
            ),
            lilith = LilithSpec(
                pose = LilithPoses.RELAXED_SUMMARY,
                action = LilithActions.POINT_TO_SUMMARY,
                expression = LilithExpressions.SOFT_SUMMARY
            ),
            voice = VoiceSpec(
                emotion = VoiceEmotions.SOFT_SUMMARY,
                speed = 0.94,
                pitch = -1,
                ttsText = tts
            ),
            subtitle = SubtitleSpec(text = SubtitleConverter.toSubtitleText(tts)),
            timing = TimingSpec(targetDurationSec = 10),
            camera = CameraSpec(motion = CameraMotions.SLOW_ZOOM_OUT),
            qualityCheck = QualityCheckSpec(mustShowChoices4 = false)
        )
    }

    private fun validateEpisodeInput(input: EpisodeInput) {
        require(input.episode.episodeId.isNotBlank()) { "episode_id is empty." }
        require(input.episode.title.isNotBlank()) { "title is empty." }
        require(input.questionSet.question.isNotBlank()) { "question is empty." }
        require(input.questionSet.choices.size == 4) { "choices must have exactly 4 items." }
        require(input.questionSet.choices.none { it.isBlank() }) { "choices contain blank item." }
        require(input.questionSet.answerIndex in 1..4) { "answerIndex must be 1..4." }

        val selectedChoice = input.questionSet.choices[input.questionSet.answerIndex - 1].trim()
        require(selectedChoice == input.questionSet.answerText.trim()) {
            "answerText does not match selected choice."
        }

        require(input.learning.hint.isNotBlank()) { "hint is empty." }
        require(input.learning.reason.isNotBlank()) { "reason is empty." }
        require(input.learning.summary.size == 3) { "summary must have exactly 3 items." }
        require(input.learning.summary.none { it.isBlank() }) { "summary contains blank item." }
        require(input.style.subtitleRule == SceneSlateRules.SUBTITLE_SAME_AS_TTS) {
            "subtitleRule must be same_as_tts."
        }
        require(input.episode.targetDurationSec <= 60) { "targetDurationSec must be 60 or less." }
    }

    private fun makeNumberedChoices(choices: List<String>): List<String> {
        return choices.mapIndexed { index, choice -> "${toKoreanChoiceNumber(index + 1)} $choice" }
    }

    private fun makeShortChoices(choices: List<String>): List<String> {
        return choices.mapIndexed { index, choice ->
            val short = choice
                .replace("이 된다", "")
                .replace("가 된다", "")
                .replace("변하지 않는다", "그대로")
                .trim()
            "${toKoreanChoiceNumber(index + 1)} $short"
        }
    }

    private fun toKoreanChoiceNumber(index: Int): String {
        return when (index) {
            1 -> "①"
            2 -> "②"
            3 -> "③"
            4 -> "④"
            else -> throw IllegalArgumentException("Choice index must be 1..4")
        }
    }

    private fun makeBoardQuestion(question: String): String {
        return question
            .replace("저항이 일정할 때, ", "저항 일정,\n")
            .replace("전압이 2배가 되면 ", "전압 2배면\n")
            .replace("전류는 어떻게 되는가?", "전류는?")
            .trim()
    }

    private fun extractKeyCondition(input: EpisodeInput): String {
        val hint = input.learning.hint
        return when {
            hint.contains("저항") && hint.contains("일정") -> "R 일정"
            hint.contains("전압") && hint.contains("일정") -> "V 일정"
            hint.contains("전류") && hint.contains("일정") -> "I 일정"
            else -> "핵심 조건"
        }
    }

    private fun makeBoardHint(input: EpisodeInput): String {
        return when (extractKeyCondition(input)) {
            "R 일정" -> "R이 그대로면\nV 변화가 I에 반영"
            "V 일정" -> "V가 그대로면\nR 변화가 I에 반영"
            "I 일정" -> "I가 그대로면\nV와 R 관계 확인"
            else -> input.learning.hint
        }
    }

    private fun normalizeSolutionSteps(steps: List<String>): List<String> {
        val safeSteps = if (steps.size >= 3) steps.take(3) else steps + List(3 - steps.size) { "핵심 관계 확인" }
        return safeSteps.mapIndexed { index, step -> "${index + 1}. $step" }
    }

    private fun makeSolutionConclusion(input: EpisodeInput): String {
        return when {
            input.learning.reason.contains("전류도 2배") -> "그래서 전압이 2배면 전류도 2배가 돼."
            input.learning.reason.contains("절반") -> "그래서 결과는 절반이 돼."
            input.learning.reason.contains("0.09C") || input.learning.reason.contains("분극") -> "Q' = 0.09C"
            else -> input.learning.solutionSteps.lastOrNull() ?: input.learning.reason
        }
    }

    private fun makeShortAnswerReason(input: EpisodeInput): String {
        return when {
            input.learning.reason.contains("전류도 2배") -> "전압이 2배면 전류도 2배야."
            input.learning.reason.contains("0.09C") || input.learning.reason.contains("분극") -> "분극 전하량은 0.09C야."
            input.learning.reason.contains("비례") -> "핵심 조건에 따라 비례 관계가 성립해."
            else -> input.learning.solutionSteps.lastOrNull() ?: input.learning.reason
        }
    }

    private fun makeBoardAnswerReason(input: EpisodeInput): String {
        return when {
            input.learning.reason.contains("전류도 2배") -> "R 일정 → V 2배 → I 2배"
            input.learning.reason.contains("0.09C") || input.learning.reason.contains("분극") -> "Q' = Q(1 - 1/εr) → 0.09C"
            input.learning.reason.contains("비례") -> "조건 확인 → 비례 관계"
            else -> input.learning.solutionSteps.lastOrNull() ?: input.learning.reason
        }
    }

    private fun normalizeSummary(summary: List<String>): List<String> {
        val fixed = if (summary.size >= 3) summary.take(3) else summary + List(3 - summary.size) { "핵심 조건 확인" }
        return fixed.map { it.trim() }
    }
}
