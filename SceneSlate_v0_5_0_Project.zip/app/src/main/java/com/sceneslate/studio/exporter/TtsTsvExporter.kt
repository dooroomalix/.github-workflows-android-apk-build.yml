package com.sceneslate.studio.exporter

import com.sceneslate.studio.generator.SubtitleConverter
import com.sceneslate.studio.model.SceneSpecDocument
import java.io.File
import java.util.Locale

object TtsTsvExporter {
    private const val HEADER = "id\tcharacter\tscene\temotion\tspeed\tpitch\ttext\tfilename"

    fun export(document: SceneSpecDocument): String {
        validate(document)
        val lines = mutableListOf(HEADER)

        document.scenes.forEachIndexed { index, scene ->
            val id = "%03d".format(Locale.US, index + 1)
            val character = sanitize(document.character.displayName.ifBlank { document.character.characterId })
            val row = listOf(
                id,
                character,
                sanitize(scene.sceneId),
                sanitize(scene.voice.emotion),
                String.format(Locale.US, "%.2f", scene.voice.speed),
                scene.voice.pitch.toString(),
                sanitize(scene.voice.ttsText),
                sanitize(createWavFilename(document.episode.episodeId, scene.sceneId))
            ).joinToString("\t")
            lines.add(row)
        }

        return lines.joinToString("\n")
    }

    private fun createWavFilename(episodeId: String, sceneId: String): String {
        val sceneName = when (sceneId) {
            "SC01" -> "opening"
            "SC02" -> "choices"
            "SC03" -> "hint"
            "SC04" -> "solution"
            "SC05" -> "answer"
            "SC06" -> "summary"
            else -> "scene"
        }
        return "${episodeId}_${sceneId}_${sceneName}.wav"
    }

    private fun sanitize(value: String): String {
        return value.replace("\t", " ").replace("\r", " ").replace("\n", " ").trim()
    }

    private fun validate(document: SceneSpecDocument) {
        require(document.episode.episodeId.isNotBlank()) { "episodeId is empty." }
        require(document.scenes.size == 6) { "SceneSpecDocument must contain exactly 6 scenes." }
        val expectedSceneIds = listOf("SC01", "SC02", "SC03", "SC04", "SC05", "SC06")
        val actualSceneIds = document.scenes.map { it.sceneId }
        require(actualSceneIds == expectedSceneIds) { "Scene IDs must be SC01~SC06 in order. actual=$actualSceneIds" }

        document.scenes.forEach { scene ->
            require(scene.voice.ttsText.isNotBlank()) { "${scene.sceneId} voice.ttsText is empty." }
            require(scene.voice.emotion.isNotBlank()) { "${scene.sceneId} voice.emotion is empty." }
            require(scene.voice.speed > 0.0) { "${scene.sceneId} voice.speed must be greater than 0." }
            require(scene.voice.pitch in -12..12) { "${scene.sceneId} voice.pitch seems invalid: ${scene.voice.pitch}" }
            require(SubtitleConverter.findInvalidPauseTags(scene.voice.ttsText).isEmpty()) { "${scene.sceneId} has invalid pause tag." }
        }
    }
}

object TtsTsvFileWriter {
    fun writeToFile(document: SceneSpecDocument, outputDir: File): File {
        val ttsDir = File(outputDir, "tts")
        if (!ttsDir.exists()) ttsDir.mkdirs()
        val file = File(ttsDir, "batch_input.tsv")
        file.writeText(TtsTsvExporter.export(document), Charsets.UTF_8)
        return file
    }
}
