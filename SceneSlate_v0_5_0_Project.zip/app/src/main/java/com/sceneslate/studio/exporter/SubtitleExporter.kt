package com.sceneslate.studio.exporter

import com.sceneslate.studio.generator.SubtitleConverter
import com.sceneslate.studio.model.SceneSpecDocument
import com.sceneslate.studio.model.SceneSlateRules
import java.io.File

object SubtitleExporter {
    private const val CAPTION_HEADER = "scene_id\tsubtitle_text"

    fun exportSceneCaptionTsv(document: SceneSpecDocument): String {
        validate(document)
        val lines = mutableListOf(CAPTION_HEADER)
        document.scenes.forEach { scene ->
            val sceneId = sanitizeCell(scene.sceneId)
            val subtitleText = scene.subtitle.text
                .replace("\r", "")
                .replace("\n", "\\n")
                .replace("\t", " ")
                .trim()
            lines.add("$sceneId\t$subtitleText")
        }
        return lines.joinToString("\n")
    }

    fun exportSubtitlePreview(document: SceneSpecDocument): String {
        validate(document)
        return buildString {
            document.scenes.forEachIndexed { index, scene ->
                append("[${scene.sceneId}]")
                append("\n")
                append(scene.subtitle.text.trim())
                append("\n")
                if (index != document.scenes.lastIndex) append("\n")
            }
        }
    }

    private fun validate(document: SceneSpecDocument) {
        require(document.scenes.size == 6) { "SceneSpecDocument must contain exactly 6 scenes." }
        document.scenes.forEach { scene ->
            require(scene.subtitle.rule == SceneSlateRules.SUBTITLE_SAME_AS_TTS) { "${scene.sceneId} subtitle rule must be same_as_tts." }
            require(scene.voice.ttsText.isNotBlank()) { "${scene.sceneId} voice.ttsText is empty." }
            require(scene.subtitle.text.isNotBlank()) { "${scene.sceneId} subtitle.text is empty." }
            require(!scene.subtitle.text.contains("[pause=")) { "${scene.sceneId} subtitle contains pause tag." }
            require(SubtitleConverter.matchesTts(scene.voice.ttsText, scene.subtitle.text)) { "${scene.sceneId} subtitle does not match TTS." }
        }
    }

    private fun sanitizeCell(value: String): String {
        return value.replace("\t", " ").replace("\r", " ").replace("\n", " ").trim()
    }
}

object SubtitleFileWriter {
    fun writeToFiles(document: SceneSpecDocument, outputDir: File): List<File> {
        val subtitlesDir = File(outputDir, "subtitles")
        if (!subtitlesDir.exists()) subtitlesDir.mkdirs()

        val sceneCaptionFile = File(subtitlesDir, "scene_caption.tsv")
        val previewFile = File(subtitlesDir, "subtitle_preview.txt")

        sceneCaptionFile.writeText(SubtitleExporter.exportSceneCaptionTsv(document), Charsets.UTF_8)
        previewFile.writeText(SubtitleExporter.exportSubtitlePreview(document), Charsets.UTF_8)

        return listOf(sceneCaptionFile, previewFile)
    }
}
