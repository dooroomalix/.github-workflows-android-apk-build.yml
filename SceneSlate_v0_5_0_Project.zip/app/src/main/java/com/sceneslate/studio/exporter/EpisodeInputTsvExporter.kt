package com.sceneslate.studio.exporter

import com.sceneslate.studio.model.EpisodeInput

object EpisodeInputTsvExporter {
    private const val HEADER =
        "episode_id\ttitle\tsubject\tlevel\ttarget_duration_sec\tlanguage\t" +
            "character_id\tcharacter_name\tvoice_preset\t" +
            "question\tchoice1\tchoice2\tchoice3\tchoice4\t" +
            "answer_index\tanswer_text\tcore_formula\thint\treason\t" +
            "solution1\tsolution2\tsolution3\t" +
            "summary1\tsummary2\tsummary3\tcta"

    fun export(input: EpisodeInput): String {
        validate(input)
        val row = listOf(
            input.episode.episodeId,
            input.episode.title,
            input.episode.subject,
            input.episode.level,
            input.episode.targetDurationSec.toString(),
            input.episode.language,
            input.character.characterId,
            input.character.displayName,
            input.character.voicePreset,
            input.questionSet.question,
            input.questionSet.choices[0],
            input.questionSet.choices[1],
            input.questionSet.choices[2],
            input.questionSet.choices[3],
            input.questionSet.answerIndex.toString(),
            input.questionSet.answerText,
            input.learning.coreFormula,
            input.learning.hint,
            input.learning.reason,
            input.learning.solutionSteps.getOrNull(0).orEmpty(),
            input.learning.solutionSteps.getOrNull(1).orEmpty(),
            input.learning.solutionSteps.getOrNull(2).orEmpty(),
            input.learning.summary[0],
            input.learning.summary[1],
            input.learning.summary[2],
            input.style.cta
        ).joinToString("\t") { sanitize(it) }
        return "$HEADER\n$row"
    }

    private fun validate(input: EpisodeInput) {
        require(input.questionSet.choices.size == 4) { "EpisodeInput choices must have exactly 4 items." }
        require(input.learning.summary.size == 3) { "EpisodeInput summary must have exactly 3 items." }
        require(input.questionSet.answerIndex in 1..4) { "answerIndex must be 1..4." }
    }

    private fun sanitize(value: String): String {
        return value.replace("\t", " ").replace("\r", " ").replace("\n", " ").trim()
    }
}
