SceneSlate v0.5.0 - milestone auto-check build. App auto-generates Ohm and long-question samples, self-checks outputs, and shows only PASS/FAIL plus one representative SC01 preview.
