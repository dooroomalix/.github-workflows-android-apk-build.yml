# SceneSlate v0.1.3

Fixed signing-key build for updateable APK testing.
