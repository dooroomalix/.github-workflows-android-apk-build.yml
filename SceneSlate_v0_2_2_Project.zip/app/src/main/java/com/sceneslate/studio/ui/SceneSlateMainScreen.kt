package com.sceneslate.studio.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.File

@Composable
fun SceneSlateMainScreen(viewModel: SceneSlateViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf("검수") }
    var selectedImageIndex by remember { mutableStateOf(0) }

    LaunchedEffect(uiState.imageFilePaths) {
        selectedImageIndex = 0
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "SceneSlate v0.2.2", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "샘플: 옴의 법칙", style = MaterialTheme.typography.bodyLarge)
        Text(text = "상태: ${uiState.status}", style = MaterialTheme.typography.bodyLarge)

        val passLabel = when {
            uiState.qualityReport.contains("Final Result: PASS") -> "검수 결과: PASS"
            uiState.qualityReport.contains("Final Result: FAIL") -> "검수 결과: FAIL"
            else -> "검수 결과: 대기"
        }

        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(onClick = {}, enabled = false) {
            Text(passLabel, fontWeight = FontWeight.Bold)
        }

        if (uiState.projectPath.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "결과 폴더:", style = MaterialTheme.typography.labelLarge)
            Text(text = uiState.projectPath, style = MaterialTheme.typography.bodySmall)
        }

        if (uiState.errorMessage.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "오류: ${uiState.errorMessage}", color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { viewModel.generateSampleProject(context) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("샘플 프로젝트 생성") }

        Spacer(modifier = Modifier.height(8.dp))

        if (uiState.projectPath.isNotBlank()) {
            Button(
                onClick = { copyToClipboard(context, "SceneSlate Project Path", uiState.projectPath) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("결과 경로 복사") }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SmallTabButton("검수", selectedTab) { selectedTab = "검수" }
            SmallTabButton("TTS", selectedTab) { selectedTab = "TTS" }
            SmallTabButton("자막", selectedTab) { selectedTab = "자막" }
            SmallTabButton("칠판", selectedTab) { selectedTab = "칠판" }
            SmallTabButton("이미지", selectedTab) { selectedTab = "이미지" }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val displayText = when (selectedTab) {
            "검수" -> uiState.qualityReport
            "TTS" -> uiState.batchInputText
            "자막" -> uiState.subtitlePreview
            "칠판" -> uiState.boardPreviewText
            "이미지" -> uiState.imageListText
            else -> ""
        }

        if (selectedTab == "이미지") {
            ImagePreviewPanel(
                imageFilePaths = uiState.imageFilePaths,
                imageListText = uiState.imageListText,
                selectedImageIndex = selectedImageIndex,
                onSelectImage = { selectedImageIndex = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )
        } else {
            Surface(modifier = Modifier.fillMaxWidth().weight(1f), tonalElevation = 2.dp) {
                Text(
                    text = displayText.ifBlank { "아직 생성된 내용이 없습니다." },
                    modifier = Modifier.padding(12.dp).verticalScroll(rememberScrollState()),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { copyToClipboard(context, "SceneSlate $selectedTab", displayText) },
            enabled = displayText.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("현재 내용 복사") }
    }
}

@Composable
private fun SmallTabButton(title: String, selectedTab: String, onClick: () -> Unit) {
    val modifier = Modifier.widthIn(min = 88.dp)
    if (title == selectedTab) {
        Button(onClick = onClick, modifier = modifier) { Text(title) }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier) { Text(title) }
    }
}

@Composable
private fun ImagePreviewPanel(
    imageFilePaths: List<String>,
    imageListText: String,
    selectedImageIndex: Int,
    onSelectImage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(modifier = modifier, tonalElevation = 2.dp) {
        Column(modifier = Modifier.padding(12.dp)) {
            if (imageFilePaths.isEmpty()) {
                Text(text = imageListText.ifBlank { "아직 생성된 이미지가 없습니다." })
                return@Column
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                imageFilePaths.forEachIndexed { index, path ->
                    val name = File(path).name.substringBefore(".png")
                    if (index == selectedImageIndex) {
                        Button(onClick = { onSelectImage(index) }) { Text(name) }
                    } else {
                        OutlinedButton(onClick = { onSelectImage(index) }) { Text(name) }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            val safeIndex = selectedImageIndex.coerceIn(0, imageFilePaths.lastIndex)
            val imagePath = imageFilePaths[safeIndex]
            Text(text = File(imagePath).name, style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(8.dp))

            val bitmap = remember(imagePath) {
                BitmapFactory.decodeFile(imagePath)
            }

            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = File(imagePath).name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentScale = ContentScale.Fit
                )
            } else {
                Text(text = "이미지를 불러올 수 없습니다: $imagePath")
            }
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
