package com.sceneslate.studio.renderer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.sceneslate.studio.model.BoardEmphasis
import com.sceneslate.studio.model.BoardLayouts
import com.sceneslate.studio.model.SceneSpec
import com.sceneslate.studio.model.SceneSpecDocument
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

object BoardImageRenderer {
    private const val WIDTH = 1080
    private const val HEIGHT = 1920

    fun renderAll(document: SceneSpecDocument, projectDir: File): List<File> {
        val imageDir = File(projectDir, "images")
        if (!imageDir.exists()) imageDir.mkdirs()

        return document.scenes.map { scene ->
            val file = File(imageDir, createImageFileName(scene.sceneId))
            renderScene(scene, file)
            file
        }
    }

    private fun renderScene(scene: SceneSpec, outputFile: File) {
        val bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        drawBackground(canvas)
        val boardRect = RectF(70f, 150f, 1010f, 1710f)
        drawBoard(canvas, boardRect)
        drawBoardContents(canvas, boardRect, scene)
        drawFooter(canvas, scene)

        FileOutputStream(outputFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        bitmap.recycle()
    }

    private fun drawBackground(canvas: Canvas) {
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(246, 244, 250)
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, WIDTH.toFloat(), HEIGHT.toFloat(), bgPaint)
    }

    private fun drawBoard(canvas: Canvas, rect: RectF) {
        val boardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(32, 76, 64)
            style = Paint.Style.FILL
        }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(218, 230, 222)
            style = Paint.Style.STROKE
            strokeWidth = 8f
        }
        canvas.drawRoundRect(rect, 36f, 36f, boardPaint)
        canvas.drawRoundRect(rect, 36f, 36f, strokePaint)
    }

    private fun drawBoardContents(canvas: Canvas, boardRect: RectF, scene: SceneSpec) {
        val padding = 58f
        val contentRect = RectF(
            boardRect.left + padding,
            boardRect.top + padding,
            boardRect.right - padding,
            boardRect.bottom - padding
        )

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 250, 214)
            textSize = when (scene.board.layout) {
                BoardLayouts.ANSWER_LARGE -> 74f
                else -> 58f
            }
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(242, 247, 237)
            textSize = bodyTextSizeFor(scene.board.layout)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 231, 148)
            textSize = bodyTextSizeFor(scene.board.layout) + 8f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        var y = contentRect.top + titlePaint.textSize
        canvas.drawText(scene.board.title, contentRect.left, y, titlePaint)
        y += 50f

        val textBlocks = collectTextBlocks(scene)
        val drawn = mutableListOf<DrawnBlock>()

        textBlocks.forEachIndexed { index, block ->
            val paint = choosePaint(scene, block, index, bodyPaint, accentPaint)
            val wrapped = wrapText(block, paint, contentRect.width())
            val lineHeight = paint.textSize * 1.34f
            y += if (index == 0) 18f else 22f
            val top = y - paint.textSize

            wrapped.forEach { line ->
                canvas.drawText(line, contentRect.left, y, paint)
                y += lineHeight
            }

            val bottom = y - lineHeight + 12f
            drawn.add(
                DrawnBlock(
                    rawText = block,
                    rect = RectF(contentRect.left - 12f, top - 16f, contentRect.right, bottom + 24f)
                )
            )
        }

        drawEmphasis(canvas, scene.board.emphasis, drawn)
    }

    private fun choosePaint(
        scene: SceneSpec,
        block: String,
        index: Int,
        bodyPaint: Paint,
        accentPaint: Paint
    ): Paint {
        if (scene.board.layout == BoardLayouts.ANSWER_LARGE && index <= 1) return accentPaint
        if (block.startsWith("정답")) return accentPaint
        if (block.contains("→")) return accentPaint
        return bodyPaint
    }

    private fun bodyTextSizeFor(layout: String): Float {
        return when (layout) {
            BoardLayouts.PROBLEM_CHOICES -> 49f
            BoardLayouts.CHOICE_FOCUS -> 58f
            BoardLayouts.HINT_FOCUS -> 58f
            BoardLayouts.SOLUTION_STEPS -> 55f
            BoardLayouts.ANSWER_LARGE -> 66f
            BoardLayouts.SUMMARY_THREE -> 55f
            else -> 52f
        }
    }

    private fun collectTextBlocks(scene: SceneSpec): List<String> {
        val blocks = mutableListOf<String>()
        when (scene.sceneId) {
            "SC01" -> {
                scene.board.singleContent["question"]?.let { blocks.add(it) }
                scene.board.content["choices"]?.let { blocks.addAll(it) }
            }
            "SC02" -> {
                scene.board.content["choices"]?.let { blocks.addAll(it) }
                scene.board.singleContent["key_condition"]?.let { blocks.add("조건: $it") }
            }
            "SC03" -> {
                scene.board.singleContent["formula"]?.let { blocks.add(it) }
                scene.board.singleContent["key_condition"]?.let { blocks.add(it) }
                scene.board.singleContent["hint_text"]?.let { blocks.add(it) }
            }
            "SC04" -> {
                scene.board.content["steps"]?.let { blocks.addAll(it) }
                scene.board.singleContent["conclusion"]?.let { blocks.add("결론: $it") }
            }
            "SC05" -> {
                scene.board.singleContent["answer"]?.let { blocks.add(it) }
                scene.board.singleContent["answer_text"]?.let { blocks.add(it) }
                scene.board.singleContent["reason"]?.let { blocks.add(it) }
            }
            "SC06" -> {
                scene.board.content["summary"]?.let { blocks.addAll(it) }
                scene.board.singleContent["cta"]?.let { blocks.add(it) }
            }
            else -> {
                scene.board.singleContent.values.forEach { blocks.add(it) }
                scene.board.content.values.forEach { blocks.addAll(it) }
            }
        }
        return blocks.map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val result = mutableListOf<String>()
        text.split("\n").forEach { paragraph ->
            val words = paragraph.split(" ").filter { it.isNotBlank() }
            if (words.size <= 1) {
                result.addAll(wrapByCharacter(paragraph, paint, maxWidth))
            } else {
                var line = ""
                words.forEach { word ->
                    val candidate = if (line.isEmpty()) word else "$line $word"
                    if (paint.measureText(candidate) <= maxWidth) {
                        line = candidate
                    } else {
                        if (line.isNotBlank()) result.add(line)
                        line = word
                    }
                }
                if (line.isNotBlank()) result.add(line)
            }
        }
        return result.ifEmpty { listOf(text) }
    }

    private fun wrapByCharacter(text: String, paint: Paint, maxWidth: Float): List<String> {
        val lines = mutableListOf<String>()
        var line = ""
        text.forEach { ch ->
            val candidate = line + ch
            if (paint.measureText(candidate) <= maxWidth) {
                line = candidate
            } else {
                if (line.isNotBlank()) lines.add(line)
                line = ch.toString()
            }
        }
        if (line.isNotBlank()) lines.add(line)
        return lines
    }

    private fun drawEmphasis(canvas: Canvas, emphasis: List<BoardEmphasis>, drawn: List<DrawnBlock>) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 224, 114)
            style = Paint.Style.STROKE
            strokeWidth = 8f
        }

        emphasis.forEach { item ->
            val target = drawn.firstOrNull { it.rawText.contains(item.target) || item.target.contains(it.rawText) }
                ?: return@forEach
            when (item.type) {
                "circle" -> canvas.drawOval(target.rect, paint)
                "box" -> canvas.drawRoundRect(target.rect, 18f, 18f, paint)
                "underline" -> canvas.drawLine(
                    target.rect.left,
                    target.rect.bottom,
                    target.rect.right - 24f,
                    target.rect.bottom,
                    paint
                )
                else -> canvas.drawRoundRect(target.rect, 18f, 18f, paint)
            }
        }
    }

    private fun drawFooter(canvas: Canvas, scene: SceneSpec) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(95, 81, 150)
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("SceneSlate · ${scene.sceneId} · ${scene.sceneTitle}", WIDTH / 2f, 1810f, paint)
    }

    private fun createImageFileName(sceneId: String): String {
        val suffix = when (sceneId) {
            "SC01" -> "problem"
            "SC02" -> "choices"
            "SC03" -> "hint"
            "SC04" -> "solution"
            "SC05" -> "answer"
            "SC06" -> "summary"
            else -> "scene"
        }
        return "${sceneId}_$suffix.png"
    }

    private data class DrawnBlock(
        val rawText: String,
        val rect: RectF
    )
}
