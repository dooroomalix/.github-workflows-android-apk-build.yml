# SceneSlate v0.2.0

SceneSlate Studio prototype.

v0.2.0 adds board PNG rendering from board_preview data.
