SceneSlate v0.2.10 - image preview mode improvements
