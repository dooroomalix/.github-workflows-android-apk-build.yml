package com.sceneslate.studio.model

import kotlinx.serialization.Serializable

@Serializable
data class ProjectInfo(
    val appName: String = "SceneSlate",
    val projectName: String = "SceneSlate Studio",
    val codename: String = "SSlate",
    val version: String = "0.2.6"
)

@Serializable
data class EpisodeInfo(
    val episodeId: String,
    val title: String,
    val subject: String = "general",
    val level: String = "basic",
    val targetDurationSec: Int = 45,
    val language: String = "ko"
)

@Serializable
data class CharacterInfo(
    val characterId: String = "lilith",
    val displayName: String = "리리스",
    val role: String = "sample_host",
    val voicePreset: String = "Lilith_CalmTeacher"
)

@Serializable
data class QuestionSet(
    val question: String,
    val choices: List<String>,
    val answerIndex: Int,
    val answerText: String
)

@Serializable
data class LearningInfo(
    val coreFormula: String = "",
    val hint: String,
    val reason: String,
    val solutionSteps: List<String>,
    val summary: List<String>
)

@Serializable
data class StyleInfo(
    val sceneCount: Int = 6,
    val format: String = "vertical_9_16",
    val subtitleRule: String = SceneSlateRules.SUBTITLE_SAME_AS_TTS,
    val boardRole: String = SceneSlateRules.BOARD_LEARNING_INFORMATION,
    val tone: String = "calm_teacher_dark_academy",
    val cta: String = "다음 문제도 풀어보자."
)

@Serializable
data class EpisodeInput(
    val project: ProjectInfo = ProjectInfo(),
    val episode: EpisodeInfo,
    val character: CharacterInfo = CharacterInfo(),
    val questionSet: QuestionSet,
    val learning: LearningInfo,
    val style: StyleInfo = StyleInfo()
)

@Serializable
data class SceneSpecDocument(
    val project: ProjectInfo = ProjectInfo(),
    val episode: EpisodeInfo,
    val character: CharacterInfo,
    val globalRules: GlobalRules = GlobalRules(),
    val scenes: List<SceneSpec>
)

@Serializable
data class GlobalRules(
    val subtitleRule: String = SceneSlateRules.SUBTITLE_SAME_AS_TTS,
    val boardRole: String = SceneSlateRules.BOARD_LEARNING_INFORMATION,
    val sceneStructure: List<String> = listOf(
        SceneTypes.PROBLEM_INTRO,
        SceneTypes.CHOICE_FOCUS,
        SceneTypes.HINT,
        SceneTypes.SOLUTION,
        SceneTypes.ANSWER_REVEAL,
        SceneTypes.SUMMARY
    )
)

@Serializable
data class SceneSpec(
    val sceneId: String,
    val sceneType: String,
    val sceneTitle: String,
    val board: BoardSpec,
    val lilith: LilithSpec,
    val voice: VoiceSpec,
    val subtitle: SubtitleSpec,
    val timing: TimingSpec,
    val camera: CameraSpec,
    val qualityCheck: QualityCheckSpec
)

@Serializable
data class BoardSpec(
    val layout: String,
    val title: String,
    val content: Map<String, List<String>> = emptyMap(),
    val singleContent: Map<String, String> = emptyMap(),
    val emphasis: List<BoardEmphasis> = emptyList()
)

@Serializable
data class BoardEmphasis(
    val type: String,
    val target: String
)

@Serializable
data class LilithSpec(
    val pose: String,
    val action: String,
    val expression: String,
    val position: String = "right_side"
)

@Serializable
data class VoiceSpec(
    val emotion: String,
    val speed: Double,
    val pitch: Int,
    val ttsText: String
)

@Serializable
data class SubtitleSpec(
    val rule: String = SceneSlateRules.SUBTITLE_SAME_AS_TTS,
    val text: String
)

@Serializable
data class TimingSpec(
    val targetDurationSec: Int
)

@Serializable
data class CameraSpec(
    val motion: String
)

@Serializable
data class QualityCheckSpec(
    val mustShowBoard: Boolean = true,
    val mustShowChoices4: Boolean = false,
    val subtitleMatchesTts: Boolean = true,
    val safeAreaRequired: Boolean = true
)

@Serializable
data class BoardPreviewDocument(
    val episodeId: String,
    val title: String,
    val boards: List<BoardPreviewItem>
)

@Serializable
data class BoardPreviewItem(
    val sceneId: String,
    val layout: String,
    val title: String,
    val textBlocks: List<String>,
    val emphasis: List<BoardEmphasis> = emptyList()
)

@Serializable
data class QualityReport(
    val finalResult: String,
    val sections: List<QualitySection>
)

@Serializable
data class QualitySection(
    val name: String,
    val result: String,
    val messages: List<String> = emptyList()
)

object SceneSlateRules {
    const val SUBTITLE_SAME_AS_TTS = "same_as_tts"
    const val BOARD_LEARNING_INFORMATION = "learning_information"
}

object SceneTypes {
    const val PROBLEM_INTRO = "problem_intro"
    const val CHOICE_FOCUS = "choice_focus"
    const val HINT = "hint"
    const val SOLUTION = "solution"
    const val ANSWER_REVEAL = "answer_reveal"
    const val SUMMARY = "summary"
}

object BoardLayouts {
    const val PROBLEM_CHOICES = "problem_choices"
    const val CHOICE_FOCUS = "choice_focus"
    const val HINT_FOCUS = "hint_focus"
    const val SOLUTION_STEPS = "solution_steps"
    const val ANSWER_LARGE = "answer_large"
    const val SUMMARY_THREE = "summary_three"
}

object LilithPoses {
    const val STANDING_POINTING_BOARD = "standing_pointing_board"
    const val SIDE_POINTING_CHOICES = "side_pointing_choices"
    const val LEAN_POINTING_KEY = "lean_pointing_key"
    const val WRITING_ON_BOARD = "writing_on_board"
    const val CONFIDENT_POINTING_ANSWER = "confident_pointing_answer"
    const val RELAXED_SUMMARY = "relaxed_summary"
}

object LilithActions {
    const val POINT_TO_QUESTION = "point_to_question"
    const val COMPARE_CHOICES = "compare_choices"
    const val UNDERLINE_KEY_CONDITION = "underline_key_condition"
    const val WRITE_SOLUTION_STEPS = "write_solution_steps"
    const val CIRCLE_ANSWER = "circle_answer"
    const val POINT_TO_SUMMARY = "point_to_summary"
}

object LilithExpressions {
    const val CALM_CHALLENGE = "calm_challenge"
    const val TEACHER_FOCUS = "teacher_focus"
    const val SECRET_HINT = "secret_hint"
    const val FOCUSED_EXPLAIN = "focused_explain"
    const val CONFIDENT_REVEAL = "confident_reveal"
    const val SOFT_SUMMARY = "soft_summary"
}

object VoiceEmotions {
    const val CALM_CHALLENGE = "calm_challenge"
    const val TEACHER_FOCUS = "teacher_focus"
    const val LOW_HINT = "low_hint"
    const val CLEAR_EXPLAIN = "clear_explain"
    const val CONFIDENT_REVEAL = "confident_reveal"
    const val SOFT_SUMMARY = "soft_summary"
}

object CameraMotions {
    const val SLIGHT_ZOOM_IN = "slight_zoom_in"
    const val BOARD_FOCUS_PAN = "board_focus_pan"
    const val SLOW_ZOOM_IN = "slow_zoom_in"
    const val STATIC = "static"
    const val ANSWER_POP_ZOOM = "answer_pop_zoom"
    const val SLOW_ZOOM_OUT = "slow_zoom_out"
}
