package com.sceneslate.studio.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sceneslate.studio.exporter.SceneSlateProjectExporter
import com.sceneslate.studio.generator.SceneSpecGenerator
import com.sceneslate.studio.sample.SampleEpisodeFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

data class SceneSlateUiState(
    val status: String = "대기",
    val projectPath: String = "",
    val qualityReport: String = "",
    val batchInputText: String = "",
    val subtitlePreview: String = "",
    val boardPreviewText: String = "",
    val imageListText: String = "",
    val errorMessage: String = ""
)

class SceneSlateViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(SceneSlateUiState())
    val uiState: StateFlow<SceneSlateUiState> = _uiState

    fun generateSampleProject(context: Context) {
        viewModelScope.launch {
            try {
                _uiState.value = SceneSlateUiState(status = "생성 중")
                val rootDir = File(context.filesDir, "SceneSlateProjects")
                val episodeInput = SampleEpisodeFactory.createOhmsLawEpisode()
                val sceneSpecDocument = SceneSpecGenerator.generate(episodeInput)
                val result = SceneSlateProjectExporter.exportProject(episodeInput, sceneSpecDocument, rootDir)

                val qualityReportFile = File(result.projectDir, "quality_report.txt")
                val batchInputFile = File(result.projectDir, "tts/batch_input.tsv")
                val subtitlePreviewFile = File(result.projectDir, "subtitles/subtitle_preview.txt")
                val boardPreviewFile = File(result.projectDir, "board/board_preview.json")
                val imagesDir = File(result.projectDir, "images")
                val imageListText = if (imagesDir.exists()) {
                    imagesDir.listFiles()?.sortedBy { it.name }?.joinToString("\n") { file ->
                        "${file.name}  (${file.length()} bytes)"
                    }.orEmpty()
                } else {
                    "images 폴더가 없습니다."
                }

                _uiState.value = SceneSlateUiState(
                    status = "완료",
                    projectPath = result.projectDir.absolutePath,
                    qualityReport = qualityReportFile.readText(Charsets.UTF_8),
                    batchInputText = batchInputFile.readText(Charsets.UTF_8),
                    subtitlePreview = subtitlePreviewFile.readText(Charsets.UTF_8),
                    boardPreviewText = boardPreviewFile.readText(Charsets.UTF_8),
                    imageListText = imageListText
                )
            } catch (e: Exception) {
                _uiState.value = SceneSlateUiState(status = "실패", errorMessage = e.message ?: "알 수 없는 오류")
            }
        }
    }
}
