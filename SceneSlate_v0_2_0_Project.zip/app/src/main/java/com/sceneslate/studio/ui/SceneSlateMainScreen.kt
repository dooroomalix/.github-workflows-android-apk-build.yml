package com.sceneslate.studio.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun SceneSlateMainScreen(viewModel: SceneSlateViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf("검수") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "SceneSlate v0.2.0", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "샘플: 옴의 법칙", style = MaterialTheme.typography.bodyLarge)
        Text(text = "상태: ${uiState.status}", style = MaterialTheme.typography.bodyLarge)

        if (uiState.projectPath.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "결과 폴더:", style = MaterialTheme.typography.labelLarge)
            Text(text = uiState.projectPath, style = MaterialTheme.typography.bodySmall)
        }

        if (uiState.errorMessage.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "오류: ${uiState.errorMessage}", color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { viewModel.generateSampleProject(context) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("샘플 프로젝트 생성") }

        Spacer(modifier = Modifier.height(8.dp))

        if (uiState.projectPath.isNotBlank()) {
            Button(
                onClick = { copyToClipboard(context, "SceneSlate Project Path", uiState.projectPath) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("결과 경로 복사") }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallTabButton("검수", selectedTab) { selectedTab = "검수" }
            SmallTabButton("TTS", selectedTab) { selectedTab = "TTS" }
            SmallTabButton("자막", selectedTab) { selectedTab = "자막" }
            SmallTabButton("칠판", selectedTab) { selectedTab = "칠판" }
            SmallTabButton("이미지", selectedTab) { selectedTab = "이미지" }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val displayText = when (selectedTab) {
            "검수" -> uiState.qualityReport
            "TTS" -> uiState.batchInputText
            "자막" -> uiState.subtitlePreview
            "칠판" -> uiState.boardPreviewText
            "이미지" -> uiState.imageListText
            else -> ""
        }

        Surface(modifier = Modifier.fillMaxWidth().weight(1f), tonalElevation = 2.dp) {
            Text(
                text = displayText.ifBlank { "아직 생성된 내용이 없습니다." },
                modifier = Modifier.padding(12.dp).verticalScroll(rememberScrollState()),
                style = MaterialTheme.typography.bodySmall
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = { copyToClipboard(context, "SceneSlate $selectedTab", displayText) },
            enabled = displayText.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("현재 내용 복사") }
    }
}

@Composable
private fun RowScope.SmallTabButton(title: String, selectedTab: String, onClick: () -> Unit) {
    if (title == selectedTab) {
        Button(onClick = onClick, modifier = Modifier.weight(1f)) { Text(title) }
    } else {
        OutlinedButton(onClick = onClick, modifier = Modifier.weight(1f)) { Text(title) }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
