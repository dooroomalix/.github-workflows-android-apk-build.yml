SceneSlate v0.2.11 - version bump for APK update verification
