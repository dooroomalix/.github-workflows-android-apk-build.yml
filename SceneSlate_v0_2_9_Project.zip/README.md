SceneSlate v0.2.9 - image preview top-aligned scroll fix
