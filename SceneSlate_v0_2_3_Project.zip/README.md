SceneSlate v0.2.3 - readable board PNG update
