package com.sceneslate.studio.sample

import com.sceneslate.studio.model.*

object SampleEpisodeFactory {
    fun createOhmsLawEpisode(): EpisodeInput {
        return EpisodeInput(
            project = ProjectInfo(
                appName = "SceneSlate",
                projectName = "SceneSlate Studio",
                codename = "SSlate",
                version = "0.2.0"
            ),
            episode = EpisodeInfo(
                episodeId = "SSlate_EP001",
                title = "옴의 법칙",
                subject = "회로이론",
                level = "초급",
                targetDurationSec = 45,
                language = "ko"
            ),
            character = CharacterInfo(
                characterId = "lilith",
                displayName = "리리스",
                role = "sample_host",
                voicePreset = "Lilith_CalmTeacher"
            ),
            questionSet = QuestionSet(
                question = "저항이 일정할 때, 전압이 2배가 되면 전류는 어떻게 되는가?",
                choices = listOf("절반이 된다", "2배가 된다", "4배가 된다", "변하지 않는다"),
                answerIndex = 2,
                answerText = "2배가 된다"
            ),
            learning = LearningInfo(
                coreFormula = "I = V / R",
                hint = "저항이 일정하다는 조건이야.",
                reason = "저항 R이 일정하면 전류 I는 전압 V에 비례한다. 따라서 전압이 2배가 되면 전류도 2배가 된다.",
                solutionSteps = listOf("I = V / R", "R은 일정", "V 2배 → I 2배"),
                summary = listOf("조건 먼저 확인", "R 일정이면 I는 V에 비례", "공식은 뜻으로 기억")
            ),
            style = StyleInfo(
                sceneCount = 6,
                format = "vertical_9_16",
                subtitleRule = SceneSlateRules.SUBTITLE_SAME_AS_TTS,
                boardRole = SceneSlateRules.BOARD_LEARNING_INFORMATION,
                tone = "calm_teacher_dark_academy",
                cta = "다음 문제도 풀어보자."
            )
        )
    }
}
