package com.sceneslate.studio.renderer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.sceneslate.studio.model.SceneSpec
import com.sceneslate.studio.model.SceneSpecDocument
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

object BoardImageRenderer {
    private const val WIDTH = 1080
    private const val HEIGHT = 1920

    private val boardRect = RectF(54f, 104f, 1026f, 1788f)
    private const val PAD = 58f

    fun renderAll(document: SceneSpecDocument, projectDir: File): List<File> {
        val imageDir = File(projectDir, "images")
        if (!imageDir.exists()) imageDir.mkdirs()

        return document.scenes.map { scene ->
            val file = File(imageDir, createImageFileName(scene.sceneId))
            renderScene(scene, file)
            file
        }
    }

    private fun renderScene(scene: SceneSpec, outputFile: File) {
        val bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        drawBackground(canvas)
        drawBoard(canvas, boardRect)

        when (scene.sceneId) {
            "SC01" -> renderProblem(canvas, scene)
            "SC02" -> renderChoices(canvas, scene)
            "SC03" -> renderHint(canvas, scene)
            "SC04" -> renderSolution(canvas, scene)
            "SC05" -> renderAnswer(canvas, scene)
            "SC06" -> renderSummary(canvas, scene)
            else -> renderDefault(canvas, scene)
        }

        drawFooter(canvas, scene)

        FileOutputStream(outputFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        bitmap.recycle()
    }

    private fun drawBackground(canvas: Canvas) {
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(239, 235, 247)
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, WIDTH.toFloat(), HEIGHT.toFloat(), bg)
    }

    private fun drawBoard(canvas: Canvas, rect: RectF) {
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(65, 0, 0, 0)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(rect.left + 10f, rect.top + 12f, rect.right + 10f, rect.bottom + 12f), 38f, 38f, shadow)

        val board = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(20, 72, 58)
            style = Paint.Style.FILL
        }
        val strokeOuter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(224, 236, 225)
            style = Paint.Style.STROKE
            strokeWidth = 9f
        }
        val strokeInner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(78, 126, 102)
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRoundRect(rect, 38f, 38f, board)
        canvas.drawRoundRect(rect, 38f, 38f, strokeOuter)
        canvas.drawRoundRect(RectF(rect.left + 18f, rect.top + 18f, rect.right - 18f, rect.bottom - 18f), 28f, 28f, strokeInner)
    }

    private fun renderProblem(canvas: Canvas, scene: SceneSpec) {
        val titlePaint = textPaint(76f, Color.rgb(255, 246, 204), true, Paint.Align.CENTER)
        val questionPaint = textPaint(60f, Color.WHITE, true)
        val choicePaint = textPaint(54f, Color.rgb(245, 250, 242), true)
        val labelPaint = textPaint(40f, Color.rgb(255, 226, 143), true, Paint.Align.CENTER)
        val conditionPaint = textPaint(56f, Color.rgb(255, 238, 171), true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 224f, titlePaint)
        drawDivider(canvas, 262f)

        val question = scene.board.singleContent["question"].orEmpty()
        var y = 365f
        y = drawLines(canvas, wrapText(question, questionPaint, 760f), boardRect.left + PAD, y, questionPaint, 20f)
        y += 34f

        val choices = scene.board.content["choices"].orEmpty()
        choices.forEach { choice ->
            y = drawChoiceRow(canvas, choice, y, choicePaint)
            y += 24f
        }

        drawInfoBox(canvas, "조건", "R 일정", labelPaint, conditionPaint, 1350f, 1608f)
    }

    private fun renderChoices(canvas: Canvas, scene: SceneSpec) {
        val titlePaint = textPaint(74f, Color.rgb(255, 246, 204), true, Paint.Align.CENTER)
        val choicePaint = textPaint(62f, Color.WHITE, true)
        val conditionPaint = textPaint(64f, Color.rgb(255, 238, 171), true, Paint.Align.CENTER)
        val labelPaint = textPaint(42f, Color.rgb(255, 226, 143), true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 230f, titlePaint)
        drawDivider(canvas, 272f)

        var y = 385f
        scene.board.content["choices"].orEmpty().forEach { choice ->
            y = drawChoiceRow(canvas, choice, y, choicePaint)
            y += 34f
        }
        val key = scene.board.singleContent["key_condition"].orEmpty().ifBlank { "R 일정" }
        drawInfoBox(canvas, "핵심 조건", key, labelPaint, conditionPaint, 1320f, 1585f)
    }

    private fun renderHint(canvas: Canvas, scene: SceneSpec) {
        val titlePaint = textPaint(76f, Color.rgb(255, 246, 204), true, Paint.Align.CENTER)
        val formulaPaint = textPaint(92f, Color.rgb(255, 237, 157), true, Paint.Align.CENTER)
        val bodyPaint = textPaint(58f, Color.WHITE, true, Paint.Align.CENTER)
        val keyPaint = textPaint(72f, Color.rgb(255, 238, 171), true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 230f, titlePaint)
        drawDivider(canvas, 275f)

        val formula = scene.board.singleContent["formula"].orEmpty()
        val key = scene.board.singleContent["key_condition"].orEmpty()
        val hint = scene.board.singleContent["hint_text"].orEmpty()

        drawCenterBox(canvas, formula, formulaPaint, 450f, 640f)
        drawCenterBox(canvas, key, keyPaint, 740f, 900f)
        drawCenteredMultiline(canvas, wrapText(hint, bodyPaint, 760f), boardRect.centerX(), 1060f, bodyPaint, 24f)
    }

    private fun renderSolution(canvas: Canvas, scene: SceneSpec) {
        val titlePaint = textPaint(74f, Color.rgb(255, 246, 204), true, Paint.Align.CENTER)
        val stepPaint = textPaint(58f, Color.WHITE, true)
        val conclusionPaint = textPaint(58f, Color.rgb(255, 238, 171), true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 230f, titlePaint)
        drawDivider(canvas, 275f)

        var y = 405f
        val steps = scene.board.content["steps"].orEmpty()
        steps.forEach { step ->
            y = drawStepBox(canvas, step, y, stepPaint)
            y += 34f
        }
        val conclusion = scene.board.singleContent["conclusion"].orEmpty().removePrefix("그래서 ")
        drawInfoBox(canvas, "결론", conclusion, textPaint(42f, Color.rgb(255, 226, 143), true, Paint.Align.CENTER), conclusionPaint, 1310f, 1606f)
    }

    private fun renderAnswer(canvas: Canvas, scene: SceneSpec) {
        val titlePaint = textPaint(78f, Color.rgb(255, 246, 204), true, Paint.Align.CENTER)
        val answerPaint = textPaint(92f, Color.rgb(255, 238, 171), true, Paint.Align.CENTER)
        val answerTextPaint = textPaint(76f, Color.WHITE, true, Paint.Align.CENTER)
        val reasonPaint = textPaint(56f, Color.rgb(235, 245, 232), true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 230f, titlePaint)
        drawDivider(canvas, 275f)

        val answer = scene.board.singleContent["answer"].orEmpty()
        val answerText = scene.board.singleContent["answer_text"].orEmpty()
        val reason = scene.board.singleContent["reason"].orEmpty()

        drawCenterBox(canvas, answer, answerPaint, 455f, 690f, fill = Color.rgb(48, 96, 70))
        drawCenteredText(canvas, answerText, boardRect.centerX(), 840f, answerTextPaint)
        drawCenteredMultiline(canvas, wrapText(reason, reasonPaint, 760f), boardRect.centerX(), 1105f, reasonPaint, 24f)
    }

    private fun renderSummary(canvas: Canvas, scene: SceneSpec) {
        val titlePaint = textPaint(74f, Color.rgb(255, 246, 204), true, Paint.Align.CENTER)
        val summaryPaint = textPaint(58f, Color.WHITE, true)
        val ctaPaint = textPaint(54f, Color.rgb(255, 238, 171), true, Paint.Align.CENTER)

        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 230f, titlePaint)
        drawDivider(canvas, 275f)

        var y = 440f
        scene.board.content["summary"].orEmpty().forEach { item ->
            y = drawStepBox(canvas, item, y, summaryPaint)
            y += 42f
        }

        val cta = scene.board.singleContent["cta"].orEmpty()
        drawCenterBox(canvas, cta, ctaPaint, 1380f, 1580f, fill = Color.rgb(45, 91, 68))
    }

    private fun renderDefault(canvas: Canvas, scene: SceneSpec) {
        val titlePaint = textPaint(72f, Color.rgb(255, 246, 204), true, Paint.Align.CENTER)
        val bodyPaint = textPaint(54f, Color.WHITE, true)
        drawCenteredText(canvas, scene.board.title, boardRect.centerX(), 230f, titlePaint)
        drawDivider(canvas, 275f)
        drawLines(canvas, collectTextBlocks(scene).flatMap { wrapText(it, bodyPaint, 800f) }, boardRect.left + PAD, 390f, bodyPaint, 22f)
    }

    private fun drawChoiceRow(canvas: Canvas, text: String, y: Float, paint: Paint): Float {
        val rect = RectF(boardRect.left + 80f, y - 58f, boardRect.right - 80f, y + 28f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(32, 89, 67)
            style = Paint.Style.FILL
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(139, 174, 145)
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRoundRect(rect, 24f, 24f, fill)
        canvas.drawRoundRect(rect, 24f, 24f, stroke)
        canvas.drawText(text, rect.left + 36f, y, paint)
        return y + 28f
    }

    private fun drawStepBox(canvas: Canvas, text: String, y: Float, paint: Paint): Float {
        val lines = wrapText(text, paint, 760f)
        val lineHeight = paint.textSize + 18f
        val height = max(104f, lines.size * lineHeight + 36f)
        val rect = RectF(boardRect.left + 72f, y - 62f, boardRect.right - 72f, y - 62f + height)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(31, 86, 65)
            style = Paint.Style.FILL
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(128, 166, 138)
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRoundRect(rect, 24f, 24f, fill)
        canvas.drawRoundRect(rect, 24f, 24f, stroke)
        drawLines(canvas, lines, rect.left + 32f, y, paint, 18f)
        return rect.bottom
    }

    private fun drawInfoBox(canvas: Canvas, label: String, value: String, labelPaint: Paint, valuePaint: Paint, top: Float, bottom: Float) {
        val rect = RectF(boardRect.left + 96f, top, boardRect.right - 96f, bottom)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(29, 82, 63)
            style = Paint.Style.FILL
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(205, 71, 103)
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        canvas.drawRoundRect(rect, 26f, 26f, fill)
        canvas.drawRoundRect(rect, 26f, 26f, stroke)
        drawCenteredText(canvas, label, rect.centerX(), top + 54f, labelPaint)
        drawCenteredMultiline(canvas, wrapText(value, valuePaint, rect.width() - 80f), rect.centerX(), top + 128f, valuePaint, 18f)
    }

    private fun drawCenterBox(canvas: Canvas, text: String, paint: Paint, top: Float, bottom: Float, fill: Int = Color.rgb(29, 82, 63)) {
        val rect = RectF(boardRect.left + 96f, top, boardRect.right - 96f, bottom)
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = fill
            style = Paint.Style.FILL
        }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(146, 178, 148)
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        canvas.drawRoundRect(rect, 28f, 28f, fillPaint)
        canvas.drawRoundRect(rect, 28f, 28f, strokePaint)
        drawCenteredMultiline(canvas, wrapText(text, paint, rect.width() - 80f), rect.centerX(), rect.centerY() - 18f, paint, 20f, verticallyCentered = true, boxHeight = rect.height())
    }

    private fun drawDivider(canvas: Canvas, y: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(218, 199, 136)
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        canvas.drawLine(boardRect.left + 130f, y, boardRect.right - 130f, y, paint)
    }

    private fun textPaint(size: Float, color: Int, bold: Boolean, align: Paint.Align = Paint.Align.LEFT): Paint {
        return Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
            textAlign = align
        }
    }

    private fun drawLines(canvas: Canvas, lines: List<String>, x: Float, startY: Float, paint: Paint, gap: Float): Float {
        var y = startY
        val lineHeight = paint.textSize + gap
        lines.forEach { line ->
            canvas.drawText(line, x, y, paint)
            y += lineHeight
        }
        return y
    }

    private fun drawCenteredText(canvas: Canvas, text: String, x: Float, y: Float, paint: Paint) {
        val old = paint.textAlign
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(text, x, y, paint)
        paint.textAlign = old
    }

    private fun drawCenteredMultiline(
        canvas: Canvas,
        lines: List<String>,
        x: Float,
        startY: Float,
        paint: Paint,
        gap: Float,
        verticallyCentered: Boolean = false,
        boxHeight: Float = 0f
    ): Float {
        val old = paint.textAlign
        paint.textAlign = Paint.Align.CENTER
        val lineHeight = paint.textSize + gap
        var y = if (verticallyCentered) {
            startY - ((lines.size - 1) * lineHeight / 2f) + paint.textSize / 2f
        } else {
            startY
        }
        lines.forEach { line ->
            canvas.drawText(line, x, y, paint)
            y += lineHeight
        }
        paint.textAlign = old
        return y
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val result = mutableListOf<String>()
        text.split("\n").forEach { raw ->
            val paragraph = raw.trim()
            if (paragraph.isBlank()) return@forEach

            val words = paragraph.split(" ").filter { it.isNotBlank() }
            if (words.size > 1) {
                var line = ""
                words.forEach { word ->
                    val candidate = if (line.isBlank()) word else "$line $word"
                    if (paint.measureText(candidate) <= maxWidth) {
                        line = candidate
                    } else {
                        if (line.isNotBlank()) result.add(line)
                        line = word
                    }
                }
                if (line.isNotBlank()) result.add(line)
            } else {
                var line = ""
                paragraph.forEach { ch ->
                    val candidate = line + ch
                    if (paint.measureText(candidate) <= maxWidth) {
                        line = candidate
                    } else {
                        if (line.isNotBlank()) result.add(line)
                        line = ch.toString()
                    }
                }
                if (line.isNotBlank()) result.add(line)
            }
        }
        return result.ifEmpty { listOf(text) }
    }

    private fun collectTextBlocks(scene: SceneSpec): List<String> {
        val blocks = mutableListOf<String>()
        when (scene.sceneId) {
            "SC01" -> {
                scene.board.singleContent["question"]?.let { blocks.add(it) }
                scene.board.content["choices"]?.let { blocks.addAll(it) }
            }
            "SC02" -> {
                scene.board.content["choices"]?.let { blocks.addAll(it) }
                scene.board.singleContent["key_condition"]?.let { blocks.add("조건: $it") }
            }
            "SC03" -> {
                scene.board.singleContent["formula"]?.let { blocks.add(it) }
                scene.board.singleContent["key_condition"]?.let { blocks.add(it) }
                scene.board.singleContent["hint_text"]?.let { blocks.add(it) }
            }
            "SC04" -> {
                scene.board.content["steps"]?.let { blocks.addAll(it) }
                scene.board.singleContent["conclusion"]?.let { blocks.add("결론: $it") }
            }
            "SC05" -> {
                scene.board.singleContent["answer"]?.let { blocks.add(it) }
                scene.board.singleContent["answer_text"]?.let { blocks.add(it) }
                scene.board.singleContent["reason"]?.let { blocks.add(it) }
            }
            "SC06" -> {
                scene.board.content["summary"]?.let { blocks.addAll(it) }
                scene.board.singleContent["cta"]?.let { blocks.add(it) }
            }
            else -> {
                scene.board.singleContent.values.forEach { blocks.add(it) }
                scene.board.content.values.forEach { blocks.addAll(it) }
            }
        }
        return blocks.map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun drawFooter(canvas: Canvas, scene: SceneSpec) {
        val paint = textPaint(28f, Color.rgb(82, 70, 139), true, Paint.Align.CENTER)
        canvas.drawText("SceneSlate · ${scene.sceneId} · ${scene.sceneTitle}", WIDTH / 2f, 1848f, paint)
    }

    private fun createImageFileName(sceneId: String): String {
        val suffix = when (sceneId) {
            "SC01" -> "problem"
            "SC02" -> "choices"
            "SC03" -> "hint"
            "SC04" -> "solution"
            "SC05" -> "answer"
            "SC06" -> "summary"
            else -> "scene"
        }
        return "${sceneId}_$suffix.png"
    }
}
