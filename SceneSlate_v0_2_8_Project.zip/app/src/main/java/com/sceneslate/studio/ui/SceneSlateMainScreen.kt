package com.sceneslate.studio.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.io.File

@Composable
fun SceneSlateMainScreen(viewModel: SceneSlateViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf("이미지") }
    var selectedImageIndex by remember { mutableStateOf(0) }

    LaunchedEffect(uiState.imageFilePaths) {
        selectedImageIndex = 0
        if (uiState.imageFilePaths.isNotEmpty()) selectedTab = "이미지"
    }

    val passText = when {
        uiState.qualityReport.contains("Final Result: PASS") -> "PASS"
        uiState.qualityReport.contains("Final Result: FAIL") -> "FAIL"
        else -> "-"
    }
    val folderName = uiState.projectPath.substringAfterLast('/').ifBlank { "결과 없음" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Text(
            text = "SceneSlate v0.2.8",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = "${uiState.currentSampleName} · ${uiState.status} · $passText",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (uiState.projectPath.isNotBlank()) {
            Text(
                text = "결과: $folderName",
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (uiState.errorMessage.isNotBlank()) {
            Text(text = "오류: ${uiState.errorMessage}", color = MaterialTheme.colorScheme.error, maxLines = 2)
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CompactButton("옴", Modifier.weight(1f)) { viewModel.generateOhmsLawSample(context) }
            CompactButton("긴 문제", Modifier.weight(1.35f)) { viewModel.generateLongQuestionSample(context) }
            CompactOutlinedButton(
                text = "경로",
                enabled = uiState.projectPath.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { copyToClipboard(context, "SceneSlate Project Path", uiState.projectPath) }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TopTabButton("검수", selectedTab, Modifier.weight(1f)) { selectedTab = "검수" }
            TopTabButton("TTS", selectedTab, Modifier.weight(1f)) { selectedTab = "TTS" }
            TopTabButton("자막", selectedTab, Modifier.weight(1f)) { selectedTab = "자막" }
            TopTabButton("칠판", selectedTab, Modifier.weight(1f)) { selectedTab = "칠판" }
            TopTabButton("이미지", selectedTab, Modifier.weight(1.1f)) { selectedTab = "이미지" }
        }

        Spacer(modifier = Modifier.height(6.dp))

        val displayText = when (selectedTab) {
            "검수" -> uiState.qualityReport
            "TTS" -> uiState.batchInputText
            "자막" -> uiState.subtitlePreview
            "칠판" -> uiState.boardPreviewText
            "이미지" -> uiState.imageListText
            else -> ""
        }

        if (selectedTab == "이미지") {
            ImagePreviewPanel(
                imageFilePaths = uiState.imageFilePaths,
                imageListText = uiState.imageListText,
                selectedImageIndex = selectedImageIndex,
                onSelectImage = { selectedImageIndex = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )
        } else {
            Surface(modifier = Modifier.fillMaxWidth().weight(1f), tonalElevation = 2.dp) {
                Text(
                    text = displayText.ifBlank { "아직 생성된 내용이 없습니다." },
                    modifier = Modifier.padding(12.dp).verticalScroll(rememberScrollState()),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Button(
            onClick = { copyToClipboard(context, "SceneSlate $selectedTab", displayText) },
            enabled = displayText.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(42.dp)
        ) { Text("현재 내용 복사") }
    }
}

@Composable
private fun CompactButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier.height(44.dp), contentPadding = PaddingValues(horizontal = 6.dp)) {
        Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun CompactOutlinedButton(
    text: String,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(onClick = onClick, enabled = enabled, modifier = modifier.height(44.dp), contentPadding = PaddingValues(horizontal = 6.dp)) {
        Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TopTabButton(title: String, selectedTab: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val selected = title == selectedTab
    if (selected) {
        Button(onClick = onClick, modifier = modifier.height(42.dp), contentPadding = PaddingValues(horizontal = 3.dp)) {
            Text(title, maxLines = 1)
        }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier.height(42.dp), contentPadding = PaddingValues(horizontal = 3.dp)) {
            Text(title, maxLines = 1)
        }
    }
}

@Composable
private fun SceneButton(title: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, modifier = modifier.height(42.dp), contentPadding = PaddingValues(horizontal = 4.dp)) {
            Text(title, maxLines = 1)
        }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier.height(42.dp), contentPadding = PaddingValues(horizontal = 4.dp)) {
            Text(title, maxLines = 1)
        }
    }
}

@Composable
private fun ModeButton(title: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, modifier = modifier.height(42.dp), contentPadding = PaddingValues(horizontal = 4.dp)) {
            Text(title, maxLines = 1)
        }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier.height(42.dp), contentPadding = PaddingValues(horizontal = 4.dp)) {
            Text(title, maxLines = 1)
        }
    }
}

@Composable
private fun ImagePreviewPanel(
    imageFilePaths: List<String>,
    imageListText: String,
    selectedImageIndex: Int,
    onSelectImage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(modifier = modifier, tonalElevation = 2.dp) {
        Column(modifier = Modifier.padding(6.dp)) {
            var previewMode by remember { mutableStateOf("전체") }

            if (imageFilePaths.isEmpty()) {
                Text(text = imageListText.ifBlank { "아직 생성된 이미지가 없습니다." })
                return@Column
            }

            val labels = imageFilePaths.map { File(it).name.substringBefore("_") }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                labels.take(3).forEachIndexed { index, label ->
                    SceneButton(label, index == selectedImageIndex, Modifier.weight(1f)) { onSelectImage(index) }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                labels.drop(3).take(3).forEachIndexed { offset, label ->
                    val index = offset + 3
                    SceneButton(label, index == selectedImageIndex, Modifier.weight(1f)) { onSelectImage(index) }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ModeButton("전체", previewMode == "전체", Modifier.weight(1f)) { previewMode = "전체" }
                ModeButton("확대", previewMode == "확대", Modifier.weight(1f)) { previewMode = "확대" }
            }

            Spacer(modifier = Modifier.height(4.dp))

            val safeIndex = selectedImageIndex.coerceIn(0, imageFilePaths.lastIndex)
            val imagePath = imageFilePaths[safeIndex]
            Text(text = File(imagePath).name, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(4.dp))

            val bitmap = remember(imagePath) { BitmapFactory.decodeFile(imagePath) }

            if (bitmap != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    val imageModifier = if (previewMode == "전체") {
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 16f)
                    } else {
                        Modifier
                            .fillMaxWidth()
                            .height(1080.dp)
                    }

                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = File(imagePath).name,
                        modifier = imageModifier,
                        contentScale = if (previewMode == "전체") ContentScale.Fit else ContentScale.FillWidth
                    )
                }
            } else {
                Text(text = "이미지를 불러올 수 없습니다: $imagePath")
            }
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
