SceneSlate v0.2.8 - compact UI and larger preview
