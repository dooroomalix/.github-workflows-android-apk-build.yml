SceneSlate v0.4.0 - auto QA dashboard and fatigue-reduced representative preview
