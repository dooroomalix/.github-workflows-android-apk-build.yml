package com.sceneslate.studio.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.io.File

private const val APP_VERSION_LABEL = "SceneSlate v0.4.0"

@Composable
fun SceneSlateMainScreen(viewModel: SceneSlateViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var selectedImageIndex by remember { mutableStateOf(0) }
    var showDetails by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.generateLongQuestionSample(context)
    }

    LaunchedEffect(uiState.imageFilePaths) {
        selectedImageIndex = 0
    }

    val passColor = if (uiState.autoReviewResult == "PASS") Color(0xFF2E7D32) else Color(0xFFC62828)
    val folderName = uiState.projectPath.substringAfterLast('/').ifBlank { "결과 없음" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = APP_VERSION_LABEL,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        AutoReviewCard(
            result = uiState.autoReviewResult,
            sampleName = uiState.currentSampleName,
            status = uiState.status,
            folderName = folderName,
            color = passColor,
            summary = uiState.autoReviewText
        )

        if (uiState.errorMessage.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "오류: ${uiState.errorMessage}",
                color = MaterialTheme.colorScheme.error,
                maxLines = 2
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CompactButton("자동 재검수", Modifier.weight(1.25f)) { viewModel.generateLongQuestionSample(context) }
            CompactButton("옴", Modifier.weight(0.7f)) { viewModel.generateOhmsLawSample(context) }
            CompactOutlinedButton(
                text = "경로",
                enabled = uiState.projectPath.isNotBlank(),
                modifier = Modifier.weight(0.7f)
            ) { copyToClipboard(context, "SceneSlate Project Path", uiState.projectPath) }
        }

        Spacer(modifier = Modifier.height(8.dp))

        RepresentativePreview(
            imageFilePaths = uiState.imageFilePaths,
            selectedImageIndex = selectedImageIndex,
            onSelectImage = { selectedImageIndex = it },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CompactOutlinedButton(
                text = if (showDetails) "세부 닫기" else "세부 검수",
                enabled = uiState.qualityReport.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { showDetails = !showDetails }
            CompactOutlinedButton(
                text = "검수 복사",
                enabled = uiState.autoReviewText.isNotBlank(),
                modifier = Modifier.weight(1f)
            ) { copyToClipboard(context, "SceneSlate Auto Review", uiState.autoReviewText) }
        }

        if (showDetails) {
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                tonalElevation = 2.dp,
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = uiState.qualityReport.ifBlank { "세부 검수 내용이 없습니다." },
                    modifier = Modifier
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState()),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun AutoReviewCard(
    result: String,
    sampleName: String,
    status: String,
    folderName: String,
    color: Color,
    summary: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        tonalElevation = 3.dp,
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "자동 검수: ${result.ifBlank { "대기" }}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = color,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = status,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                text = "$sampleName · $folderName",
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = summary,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 8,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun RepresentativePreview(
    imageFilePaths: List<String>,
    selectedImageIndex: Int,
    onSelectImage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        tonalElevation = 2.dp,
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            if (imageFilePaths.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("대표 화면 생성 대기 중")
                }
                return@Column
            }

            val labels = imageFilePaths.map { File(it).name.substringBefore("_") }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                labels.forEachIndexed { index, label ->
                    SceneButton(label, index == selectedImageIndex) { onSelectImage(index) }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            val safeIndex = selectedImageIndex.coerceIn(0, imageFilePaths.lastIndex)
            val imagePath = imageFilePaths[safeIndex]
            val fileName = File(imagePath).name
            Text(
                text = "대표 확인: $fileName",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "기본 확인은 SC01 한 장이면 충분합니다.",
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(6.dp))

            val bitmap = remember(imagePath) { BitmapFactory.decodeFile(imagePath) }
            if (bitmap != null) {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.TopCenter
                ) {
                    val fitWidth = minOf(maxWidth, maxHeight * 9f / 16f)
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = fileName,
                        modifier = Modifier
                            .requiredWidth(fitWidth)
                            .aspectRatio(9f / 16f),
                        contentScale = ContentScale.Fit
                    )
                }
            } else {
                Text(text = "이미지를 불러올 수 없습니다: $imagePath")
            }
        }
    }
}

@Composable
private fun CompactButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(44.dp),
        contentPadding = PaddingValues(horizontal = 8.dp)
    ) {
        Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun CompactOutlinedButton(
    text: String,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(44.dp),
        contentPadding = PaddingValues(horizontal = 8.dp)
    ) {
        Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SceneButton(title: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(
            onClick = onClick,
            modifier = Modifier.widthIn(min = 62.dp).height(40.dp),
            contentPadding = PaddingValues(horizontal = 8.dp)
        ) { Text(title, maxLines = 1) }
    } else {
        OutlinedButton(
            onClick = onClick,
            modifier = Modifier.widthIn(min = 62.dp).height(40.dp),
            contentPadding = PaddingValues(horizontal = 8.dp)
        ) { Text(title, maxLines = 1) }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
