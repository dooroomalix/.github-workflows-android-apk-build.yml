package com.sceneslate.studio.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sceneslate.studio.exporter.SceneSlateProjectExporter
import com.sceneslate.studio.generator.SceneSpecGenerator
import com.sceneslate.studio.model.EpisodeInput
import com.sceneslate.studio.sample.SampleEpisodeFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

private const val APP_VERSION_LABEL = "SceneSlate v0.4.0"

data class SceneSlateUiState(
    val status: String = "대기",
    val projectPath: String = "",
    val qualityReport: String = "",
    val batchInputText: String = "",
    val subtitlePreview: String = "",
    val boardPreviewText: String = "",
    val imageListText: String = "",
    val imageFilePaths: List<String> = emptyList(),
    val currentSampleName: String = "긴 문제 자동 맞춤",
    val autoReviewResult: String = "대기",
    val autoReviewText: String = "앱을 열면 긴 문제 샘플을 자동 생성하고 자체 검수합니다.",
    val representativeImageName: String = "",
    val errorMessage: String = ""
)

class SceneSlateViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(SceneSlateUiState())
    val uiState: StateFlow<SceneSlateUiState> = _uiState

    fun generateOhmsLawSample(context: Context) {
        generateProject(context, SampleEpisodeFactory.createOhmsLawEpisode(), "옴의 법칙")
    }

    fun generateLongQuestionSample(context: Context) {
        generateProject(context, SampleEpisodeFactory.createLongQuestionEpisode(), "긴 문제 자동 맞춤")
    }

    fun generateSampleProject(context: Context) {
        generateLongQuestionSample(context)
    }

    private fun generateProject(
        context: Context,
        episodeInput: EpisodeInput,
        sampleName: String
    ) {
        viewModelScope.launch {
            try {
                _uiState.value = SceneSlateUiState(
                    status = "자동 생성 중",
                    currentSampleName = sampleName,
                    autoReviewResult = "검수 중",
                    autoReviewText = "SceneSpec, 자막, PNG 6장을 자동 생성하고 검수 중입니다."
                )

                val rootDir = File(context.filesDir, "SceneSlateProjects")
                val sceneSpecDocument = SceneSpecGenerator.generate(episodeInput)
                val result = SceneSlateProjectExporter.exportProject(episodeInput, sceneSpecDocument, rootDir)

                val qualityReportFile = File(result.projectDir, "quality_report.txt")
                val batchInputFile = File(result.projectDir, "tts/batch_input.tsv")
                val subtitlePreviewFile = File(result.projectDir, "subtitles/subtitle_preview.txt")
                val boardPreviewFile = File(result.projectDir, "board/board_preview.json")
                val imagesDir = File(result.projectDir, "images")
                val imageFiles = imagesDir.listFiles()
                    ?.filter { it.isFile && it.extension.lowercase() == "png" }
                    ?.sortedBy { it.name }
                    .orEmpty()

                val qualityReport = qualityReportFile.readText(Charsets.UTF_8)
                val imageListText = if (imageFiles.isNotEmpty()) {
                    imageFiles.joinToString("\n") { file ->
                        "${file.name}  (${file.length()} bytes)"
                    }
                } else {
                    "PNG 이미지가 없습니다."
                }

                val autoReview = buildAutoReview(
                    qualityReport = qualityReport,
                    imageFiles = imageFiles,
                    projectDir = result.projectDir,
                    sampleName = sampleName
                )

                _uiState.value = SceneSlateUiState(
                    status = "완료",
                    projectPath = result.projectDir.absolutePath,
                    qualityReport = qualityReport,
                    batchInputText = batchInputFile.readText(Charsets.UTF_8),
                    subtitlePreview = subtitlePreviewFile.readText(Charsets.UTF_8),
                    boardPreviewText = boardPreviewFile.readText(Charsets.UTF_8),
                    imageListText = imageListText,
                    imageFilePaths = imageFiles.map { it.absolutePath },
                    currentSampleName = sampleName,
                    autoReviewResult = autoReview.first,
                    autoReviewText = autoReview.second,
                    representativeImageName = imageFiles.firstOrNull { it.name.startsWith("SC01") }?.name.orEmpty()
                )
            } catch (e: Exception) {
                _uiState.value = SceneSlateUiState(
                    status = "실패",
                    currentSampleName = sampleName,
                    autoReviewResult = "FAIL",
                    autoReviewText = "자동 생성 중 오류가 발생했습니다.",
                    errorMessage = e.message ?: "알 수 없는 오류"
                )
            }
        }
    }

    private fun buildAutoReview(
        qualityReport: String,
        imageFiles: List<File>,
        projectDir: File,
        sampleName: String
    ): Pair<String, String> {
        val expected = listOf(
            "SC01_problem.png",
            "SC02_choices.png",
            "SC03_hint.png",
            "SC04_solution.png",
            "SC05_answer.png",
            "SC06_summary.png"
        )
        val names = imageFiles.map { it.name }.toSet()
        val missing = expected.filter { it !in names }
        val tiny = imageFiles.filter { it.length() < 1_000L }.map { it.name }
        val qualityPass = qualityReport.contains("Final Result: PASS")
        val sc01Ok = names.contains("SC01_problem.png")
        val projectReady = File(projectDir, "scenes/scenespec.json").exists() &&
            File(projectDir, "tts/batch_input.tsv").exists() &&
            File(projectDir, "subtitles/subtitle_preview.txt").exists() &&
            File(projectDir, "board/board_preview.json").exists()

        val pass = qualityPass && missing.isEmpty() && tiny.isEmpty() && sc01Ok && projectReady
        val result = if (pass) "PASS" else "FAIL"
        val text = buildString {
            appendLine("자동 검수: $result")
            appendLine("버전: $APP_VERSION_LABEL")
            appendLine("샘플: $sampleName")
            appendLine("품질 리포트: ${if (qualityPass) "PASS" else "FAIL"}")
            appendLine("제작 데이터: ${if (projectReady) "OK" else "확인 필요"}")
            appendLine("PNG 이미지: ${imageFiles.size}/6")
            appendLine("대표 화면 SC01: ${if (sc01Ok) "OK" else "누락"}")
            if (missing.isNotEmpty()) appendLine("누락 이미지: ${missing.joinToString()}")
            if (tiny.isNotEmpty()) appendLine("비정상 이미지 의심: ${tiny.joinToString()}")
            appendLine()
            appendLine("사용자 확인은 대표 화면 SC01 한 장만 보면 됩니다.")
        }
        return result to text.trimEnd()
    }
}
