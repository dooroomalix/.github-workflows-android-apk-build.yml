SceneSlate v0.2.7 - UI cleanup and 6-scene verification
