package com.sceneslate.studio.quality

import com.sceneslate.studio.generator.SubtitleConverter
import com.sceneslate.studio.model.*
import java.io.File

object QualityReportGenerator {
    fun generate(document: SceneSpecDocument, outputDir: File? = null): String {
        val sections = listOf(
            checkSceneSpec(document),
            checkTts(document),
            checkSubtitle(document),
            checkBoardPreview(document),
            checkOutputFiles(outputDir)
        )
        val finalResult = if (sections.all { it.result == "PASS" }) "PASS" else "FAIL"
        return renderTextReport(document, finalResult, sections)
    }

    private fun checkSceneSpec(document: SceneSpecDocument): QualitySection {
        val messages = mutableListOf<String>()
        if (document.scenes.size != 6) messages.add("SceneSpec must contain exactly 6 scenes. actual=${document.scenes.size}")
        val expectedSceneIds = listOf("SC01", "SC02", "SC03", "SC04", "SC05", "SC06")
        val actualSceneIds = document.scenes.map { it.sceneId }
        if (actualSceneIds != expectedSceneIds) messages.add("Scene IDs must be SC01~SC06 in order. actual=$actualSceneIds")

        document.scenes.forEach { scene ->
            if (scene.board.layout.isBlank()) messages.add("${scene.sceneId}: board.layout is empty.")
            if (scene.lilith.pose.isBlank()) messages.add("${scene.sceneId}: lilith.pose is empty.")
            if (scene.voice.ttsText.isBlank()) messages.add("${scene.sceneId}: voice.ttsText is empty.")
            if (scene.subtitle.text.isBlank()) messages.add("${scene.sceneId}: subtitle.text is empty.")
            if (scene.timing.targetDurationSec <= 0) messages.add("${scene.sceneId}: targetDurationSec must be greater than 0.")
            if (scene.camera.motion.isBlank()) messages.add("${scene.sceneId}: camera.motion is empty.")
        }
        checkScene01(document, messages)
        checkScene05(document, messages)
        checkScene06(document, messages)
        return section("SceneSpec", messages)
    }

    private fun checkScene01(document: SceneSpecDocument, messages: MutableList<String>) {
        val scene = document.scenes.find { it.sceneId == "SC01" } ?: run {
            messages.add("SC01 is missing.")
            return
        }
        val question = scene.board.singleContent["question"]
        val choices = scene.board.content["choices"]
        if (question.isNullOrBlank()) messages.add("SC01: board question is missing.")
        if (choices == null || choices.size != 4) messages.add("SC01: must contain exactly 4 choices.")
        if (!scene.qualityCheck.mustShowChoices4) messages.add("SC01: mustShowChoices4 should be true.")
    }

    private fun checkScene05(document: SceneSpecDocument, messages: MutableList<String>) {
        val scene = document.scenes.find { it.sceneId == "SC05" } ?: run {
            messages.add("SC05 is missing.")
            return
        }
        if (scene.board.singleContent["answer"].isNullOrBlank()) messages.add("SC05: answer is missing.")
        if (scene.board.singleContent["answer_text"].isNullOrBlank()) messages.add("SC05: answer_text is missing.")
        if (scene.board.singleContent["reason"].isNullOrBlank()) messages.add("SC05: answer reason is missing.")
        if (!scene.voice.ttsText.contains("번")) messages.add("SC05: TTS should contain answer number.")
    }

    private fun checkScene06(document: SceneSpecDocument, messages: MutableList<String>) {
        val scene = document.scenes.find { it.sceneId == "SC06" } ?: run {
            messages.add("SC06 is missing.")
            return
        }
        val summary = scene.board.content["summary"]
        if (summary == null || summary.size != 3) messages.add("SC06: summary must contain exactly 3 lines.")
    }

    private fun checkTts(document: SceneSpecDocument): QualitySection {
        val messages = mutableListOf<String>()
        document.scenes.forEach { scene ->
            val tts = scene.voice.ttsText
            if (tts.isBlank()) messages.add("${scene.sceneId}: TTS text is empty.")
            val invalidPauseTags = SubtitleConverter.findInvalidPauseTags(tts)
            if (invalidPauseTags.isNotEmpty()) messages.add("${scene.sceneId}: invalid pause tag(s): ${invalidPauseTags.joinToString(", ")}")
            if (scene.sceneId == "SC05" && !tts.contains("정답")) messages.add("SC05: TTS should contain answer reveal phrase.")
        }
        return section("TTS TSV", messages)
    }

    private fun checkSubtitle(document: SceneSpecDocument): QualitySection {
        val messages = mutableListOf<String>()
        document.scenes.forEach { scene ->
            if (scene.subtitle.rule != SceneSlateRules.SUBTITLE_SAME_AS_TTS) messages.add("${scene.sceneId}: subtitle.rule must be same_as_tts.")
            if (scene.subtitle.text.contains("[pause=")) messages.add("${scene.sceneId}: subtitle contains pause tag.")
            if (!SubtitleConverter.matchesTts(scene.voice.ttsText, scene.subtitle.text)) messages.add("${scene.sceneId}: subtitle does not match TTS.")
        }
        return section("Subtitle", messages)
    }

    private fun checkBoardPreview(document: SceneSpecDocument): QualitySection {
        val messages = mutableListOf<String>()
        document.scenes.forEach { scene ->
            val hasBoardText = scene.board.singleContent.isNotEmpty() || scene.board.content.isNotEmpty()
            if (!hasBoardText) messages.add("${scene.sceneId}: board content is empty.")
            if (scene.board.layout.isBlank()) messages.add("${scene.sceneId}: board layout is empty.")
            if (looksLikeTranscript(scene)) messages.add("${scene.sceneId}: board content looks too similar to TTS transcript.")
        }
        return section("BoardPreview", messages)
    }

    private fun looksLikeTranscript(scene: SceneSpec): Boolean {
        val boardText = buildString {
            scene.board.singleContent.values.forEach { append(it) }
            scene.board.content.values.flatten().forEach { append(it) }
        }.replace(Regex("""\s+"""), "")

        val ttsText = scene.voice.ttsText
            .replace(Regex("""\[pause=(300|500|700|1000)\]"""), "")
            .replace(Regex("""\s+"""), "")

        if (boardText.isBlank() || ttsText.isBlank()) return false
        return boardText == ttsText
    }

    private fun checkOutputFiles(outputDir: File?): QualitySection {
        if (outputDir == null) {
            return QualitySection("Output Files", "PASS", listOf("File existence check skipped. outputDir is null."))
        }
        val requiredFiles = listOf(
            "input/episode_input.json",
            "input/episode_input.tsv",
            "scenes/scenespec.json",
            "tts/batch_input.tsv",
            "subtitles/scene_caption.tsv",
            "subtitles/subtitle_preview.txt",
            "board/board_preview.json",
            "project_info.txt"
        )
        val messages = requiredFiles
            .filter { relativePath -> !File(outputDir, relativePath).exists() }
            .map { missing -> "Missing file: $missing" }
        return section("Output Files", messages)
    }

    private fun section(name: String, messages: List<String>): QualitySection {
        return QualitySection(name = name, result = if (messages.isEmpty()) "PASS" else "FAIL", messages = messages)
    }

    private fun renderTextReport(document: SceneSpecDocument, finalResult: String, sections: List<QualitySection>): String {
        return buildString {
            appendLine("SceneSlate Quality Report")
            appendLine("Version: v${document.project.version}")
            appendLine("Episode ID: ${document.episode.episodeId}")
            appendLine("Title: ${document.episode.title}")
            appendLine()
            sections.forEach { section ->
                appendLine("[${section.name}]")
                appendLine(section.result)
                section.messages.forEach { message -> appendLine("- $message") }
                appendLine()
            }
            appendLine("Final Result: $finalResult")
        }
    }
}

object QualityReportFileWriter {
    fun writeToFile(document: SceneSpecDocument, outputDir: File): File {
        if (!outputDir.exists()) outputDir.mkdirs()
        val file = File(outputDir, "quality_report.txt")
        file.writeText(QualityReportGenerator.generate(document, outputDir), Charsets.UTF_8)
        return file
    }
}
