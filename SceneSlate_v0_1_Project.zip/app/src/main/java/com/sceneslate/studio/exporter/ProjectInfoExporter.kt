package com.sceneslate.studio.exporter

import com.sceneslate.studio.model.SceneSpecDocument
import java.io.File

object ProjectInfoExporter {
    fun export(document: SceneSpecDocument): String {
        val sceneStructure = document.globalRules.sceneStructure.joinToString(" > ")
        return buildString {
            appendLine("Project: ${document.project.projectName}")
            appendLine("App: ${document.project.appName}")
            appendLine("Codename: ${document.project.codename}")
            appendLine("Version: v${document.project.version}")
            appendLine()
            appendLine("Episode ID: ${document.episode.episodeId}")
            appendLine("Title: ${document.episode.title}")
            appendLine("Subject: ${document.episode.subject}")
            appendLine("Level: ${document.episode.level}")
            appendLine("Language: ${document.episode.language}")
            appendLine("Target Duration: ${document.episode.targetDurationSec} sec")
            appendLine()
            appendLine("Character ID: ${document.character.characterId}")
            appendLine("Character Name: ${document.character.displayName}")
            appendLine("Character Role: ${document.character.role}")
            appendLine("Voice Preset: ${document.character.voicePreset}")
            appendLine()
            appendLine("Scene Count: ${document.scenes.size}")
            appendLine("Scene Structure: $sceneStructure")
            appendLine()
            appendLine("Subtitle Rule: ${document.globalRules.subtitleRule}")
            appendLine("Board Role: ${document.globalRules.boardRole}")
            appendLine("Format: vertical_9_16")
            appendLine()
            appendLine("Generated Files:")
            appendLine("- input/episode_input.json")
            appendLine("- input/episode_input.tsv")
            appendLine("- scenes/scenespec.json")
            appendLine("- tts/batch_input.tsv")
            appendLine("- subtitles/scene_caption.tsv")
            appendLine("- subtitles/subtitle_preview.txt")
            appendLine("- board/board_preview.json")
            appendLine("- project_info.txt")
            appendLine("- quality_report.txt")
        }
    }
}

object ProjectInfoFileWriter {
    fun writeToFile(document: SceneSpecDocument, outputDir: File): File {
        if (!outputDir.exists()) outputDir.mkdirs()
        val file = File(outputDir, "project_info.txt")
        file.writeText(ProjectInfoExporter.export(document), Charsets.UTF_8)
        return file
    }
}
