# SceneSlate Studio v0.1.2

SceneSlate is a character-based short-form video studio prototype.

v0.1.2 generates the core production data for a 6-scene short-form episode:

- `episode_input.json`
- `episode_input.tsv`
- `scenespec.json`
- `batch_input.tsv`
- `scene_caption.tsv`
- `subtitle_preview.txt`
- `board_preview.json`
- `project_info.txt`
- `quality_report.txt`

Internal sample character: Lilith / 리리스.
Released users should be able to use their own characters in future versions.
